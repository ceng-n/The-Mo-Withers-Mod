package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.MoWithers;
import net.endermanofdoom.mowithers.entity.monster.EntityWane;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderSpider;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderWane extends RenderSpider<EntityWane>
{
    private static final ResourceLocation WANE_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/spider_wither.png");

    public RenderWane(RenderManager renderManagerIn)
    {
        super(renderManagerIn);
        this.shadowSize *= 1.2F;
        this.layerRenderers.clear();
        this.addLayer(new LayerWaneEyes(this));
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityWane entitylivingbaseIn, float partialTickTime)
    {
        GlStateManager.scale(1.2F, 1.2F, 1.2F);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityWane entity)
    {
        return WANE_TEXTURES;
    }
    
    public class LayerWaneEyes implements LayerRenderer<EntityWane>
    {
        private final RenderWane endermanRenderer;

        public LayerWaneEyes(RenderWane endermanRendererIn)
        {
            this.endermanRenderer = endermanRendererIn;
        }

        public void doRenderLayer(EntityWane entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
            GlStateManager.depthMask(!entitylivingbaseIn.isInvisible());
            this.endermanRenderer.bindTexture(new ResourceLocation(MoWithers.MODID, "textures/entity/mob/spider_wither_eyes.png"));
            GlStateManager.enableBlend();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 15728880.0F, 0);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
            this.endermanRenderer.getMainModel().render(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
            this.endermanRenderer.setLightmap(entitylivingbaseIn);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
        }

        public boolean shouldCombineTextures()
        {
            return false;
        }
    }
}