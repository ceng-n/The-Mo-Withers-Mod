package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.entity.wither.EntityBaseWither;
import net.endermanofdoom.mowithers.entity.wither.EntityWitherAvatar;
import net.endermanofdoom.mowithers.model.ModelBaseWither;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public abstract class RenderBaseWither<T extends EntityBaseWither> extends RenderLiving<T>
{
    protected ModelBase auraModel;
    
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public RenderBaseWither(RenderManager renderManagerIn)
    {
        super(renderManagerIn, new ModelBaseWither(0.0F), 1.0F);
        this.auraModel = new ModelBaseWither(0.5F);
        this.addLayer(new LayerWitherAura(this));
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityBaseWither entitylivingbaseIn, float partialTickTime)
    {
        float f = entitylivingbaseIn.getWitherScale();
        int i = entitylivingbaseIn.getInvulTime();
        this.shadowSize = entitylivingbaseIn.width * 0.75F;
        if (i > 0)
            f -= ((float)i - partialTickTime) / 220.0F * 0.5F;
        if (entitylivingbaseIn.isChild())
        	f *= 2;
        GlStateManager.scale(f, f, f);
    }   

    protected float getDeathMaxRotation(EntityBaseWither entityLivingBaseIn)
    {
        return 145.0F;
    } 
    
    protected void applyRotations(EntityBaseWither entityLiving, float p_77043_2_, float rotationYaw, float partialTicks)
    {
        GlStateManager.rotate(180.0F - rotationYaw, 0.0F, 1.0F, 0);

        if (entityLiving.deathTime > 0)
        {
            float f = ((float)entityLiving.deathTime + partialTicks - 1.0F) / 30.0F;
            f = MathHelper.sqrt(f);

            if (f > 1.0F)
            {
                f = 1.0F;
            }

            GlStateManager.rotate(f * this.getDeathMaxRotation(entityLiving), 1.0F, 0.0F, 0);
            f *= entityLiving.getWitherScale() * 0.5F;
            GlStateManager.translate(0F, -f, -f);
        }
        else
        {
            String s = TextFormatting.getTextWithoutFormattingCodes(entityLiving.getName());

            if (s != null && ("Dinnerbone".equals(s) || "Grumm".equals(s)))
            {
                GlStateManager.translate(0.0F, entityLiving.height + 0.1F, 0);
                GlStateManager.rotate(180.0F, 0.0F, 0.0F, 1.0F);
            }
        }
    }
    
    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityBaseWither entity)
    {
        int i = entity.getInvulTime();
        return i > 0 && (i > 80 || i / 5 % 2 != 1) ? new ResourceLocation("textures/entity/wither/wither_invulnerable.png") : new ResourceLocation("textures/entity/wither/wither.png");
    }
    
    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getAuraTexture(EntityBaseWither entity)
    {
        return new ResourceLocation("textures/entity/wither/wither_armor.png");
    }
    
    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ModelBase getAuraModel(EntityBaseWither entity)
    {
        return auraModel;
    }
    
    @SuppressWarnings("hiding")
	public class LayerWitherAura<T extends EntityBaseWither> implements LayerRenderer<T>
    {
        private final RenderBaseWither<T> witherRenderer;

        public LayerWitherAura(RenderBaseWither<T> witherRendererIn)
        {
            this.witherRenderer = witherRendererIn;
        }

        public void doRenderLayer(EntityBaseWither entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
    		float savedtickage = 0;
    		if (entitylivingbaseIn.deathTicks > 0)
    			ageInTicks = savedtickage;
    		else
    			savedtickage = ageInTicks;
        	
            if (entitylivingbaseIn.isArmored() || entitylivingbaseIn.getAbsorptionAmount() > 0 || entitylivingbaseIn instanceof EntityWitherAvatar || entitylivingbaseIn.isRaidBoss())
            {
                GlStateManager.depthMask(!entitylivingbaseIn.isInvisible());
                this.witherRenderer.bindTexture(witherRenderer.getAuraTexture(entitylivingbaseIn));
                GlStateManager.matrixMode(5890);
                GlStateManager.loadIdentity();
                float f = (float)entitylivingbaseIn.ticksExisted + partialTicks;
                if (entitylivingbaseIn.getRamTime() > 10)
                {
                	f *= entitylivingbaseIn.getRamTime() * 0.1F;
                }
                float f1 = MathHelper.cos(f * 0.02F) * 3.0F;
                float f2 = f * 0.01F;
                GlStateManager.translate(f1, entitylivingbaseIn.deathTicks > 0 ? 0F : f2, 0);
                GlStateManager.matrixMode(5888);
                GlStateManager.enableNormalize();
                GlStateManager.enableBlend();
                float f3 = 1F;
                GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
                GlStateManager.color(f3, f3, f3, entitylivingbaseIn.deathTicks > 0 ? 1F : 0.8F);
                GlStateManager.disableLighting();
                GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
                this.witherRenderer.getAuraModel(entitylivingbaseIn).setLivingAnimations(entitylivingbaseIn, limbSwing, limbSwingAmount, partialTicks);
                this.witherRenderer.getAuraModel(entitylivingbaseIn).setModelAttributes(this.witherRenderer.getMainModel());
                Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
                this.witherRenderer.getAuraModel(entitylivingbaseIn).render(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
                Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
                GlStateManager.matrixMode(5890);
                GlStateManager.loadIdentity();
                GlStateManager.matrixMode(5888);
                GlStateManager.enableLighting();
                GlStateManager.disableBlend();
                GlStateManager.disableNormalize();
            }
        }

        public boolean shouldCombineTextures()
        {
            return false;
        }
    }
}