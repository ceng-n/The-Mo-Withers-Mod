package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.MoWithers;
import net.endermanofdoom.mowithers.entity.monster.EntityEvaporation;
import net.minecraft.client.model.ModelGhast;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderEvaporation extends RenderLiving<EntityEvaporation>
{
    private static final ResourceLocation GHAST_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/ghast_wither.png");
    private static final ResourceLocation GHAST_SHOOTING_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/ghast_wither_shooting.png");

    public RenderEvaporation(RenderManager renderManagerIn)
    {
        super(renderManagerIn, new ModelGhast(), 2F);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityEvaporation entity)
    {
        return entity.isAttacking() ? GHAST_SHOOTING_TEXTURES : GHAST_TEXTURES;
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityEvaporation entitylivingbaseIn, float partialTickTime)
    {
        float f1 = 5.4F;
        GlStateManager.scale(f1, f1, f1);
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
    }
}