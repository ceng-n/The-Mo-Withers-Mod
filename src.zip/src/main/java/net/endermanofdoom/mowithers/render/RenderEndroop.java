package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.MoWithers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderEnderman;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderEndroop extends RenderEnderman
{
    private static final ResourceLocation ENDROOP_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/enderman_wither.png");

    public RenderEndroop(RenderManager p_i47204_1_)
    {
        super(p_i47204_1_);
        this.shadowSize *= 1.2F;
        this.layerRenderers.clear();
        this.addLayer(new LayerEndroopEyes(this));
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityEnderman entitylivingbaseIn, float partialTickTime)
    {
        GlStateManager.scale(1.2F, 1.2F, 1.2F);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityEnderman entity)
    {
        return ENDROOP_TEXTURES;
    }
    
    public class LayerEndroopEyes implements LayerRenderer<EntityEnderman>
    {
        private final RenderEndroop endermanRenderer;

        public LayerEndroopEyes(RenderEndroop endermanRendererIn)
        {
            this.endermanRenderer = endermanRendererIn;
        }

        public void doRenderLayer(EntityEnderman entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
            GlStateManager.depthMask(!entitylivingbaseIn.isInvisible());
            this.endermanRenderer.bindTexture(new ResourceLocation(MoWithers.MODID, "textures/entity/mob/enderman_wither_eyes.png"));
            GlStateManager.enableBlend();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 15728880.0F, 0);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
            this.endermanRenderer.getMainModel().render(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
            this.endermanRenderer.setLightmap(entitylivingbaseIn);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
        }

        public boolean shouldCombineTextures()
        {
            return false;
        }
    }
}