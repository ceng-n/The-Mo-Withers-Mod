package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.MoWithers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderCreeper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.util.ResourceLocation;

public class RenderAtrophy extends RenderCreeper
{
    private static final ResourceLocation ATROPHY_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/creeper_wither.png");

    public RenderAtrophy(RenderManager p_i47204_1_)
    {
        super(p_i47204_1_);
        this.shadowSize *= 1.2F;;
        this.addLayer(new LayerAtrophyEyes(this));
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityCreeper entitylivingbaseIn, float partialTickTime)
    {
        GlStateManager.scale(1.2F, 1.2F, 1.2F);
        super.preRenderCallback(entitylivingbaseIn, partialTickTime);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityCreeper entity)
    {
        return ATROPHY_TEXTURES;
    }
    
    public class LayerAtrophyEyes implements LayerRenderer<EntityCreeper>
    {
        private final RenderAtrophy endermanRenderer;

        public LayerAtrophyEyes(RenderAtrophy endermanRendererIn)
        {
            this.endermanRenderer = endermanRendererIn;
        }

        public void doRenderLayer(EntityCreeper entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
            GlStateManager.depthMask(!entitylivingbaseIn.isInvisible());
            this.endermanRenderer.bindTexture(new ResourceLocation(MoWithers.MODID, "textures/entity/mob/creeper_wither_eyes.png"));
            GlStateManager.enableBlend();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 15728880.0F, 0);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
            this.endermanRenderer.getMainModel().render(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
            this.endermanRenderer.setLightmap(entitylivingbaseIn);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
        }

        public boolean shouldCombineTextures()
        {
            return false;
        }
    }
}
