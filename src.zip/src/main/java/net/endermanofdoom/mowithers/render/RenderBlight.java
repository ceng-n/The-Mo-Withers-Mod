package net.endermanofdoom.mowithers.render;

import net.endermanofdoom.mowithers.MoWithers;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.entity.RenderZombie;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderBlight extends RenderZombie
{
    private static final ResourceLocation BLIGHT_ZOMBIE_TEXTURES = new ResourceLocation(MoWithers.MODID, "textures/entity/mob/zombie_wither.png");

    public RenderBlight(RenderManager p_i47204_1_)
    {
        super(p_i47204_1_);
        this.shadowSize *= 1.2F;
        this.addLayer(new LayerBlightEyes(this));
    }

    /**
     * Allows the render to do state modifications necessary before the model is rendered.
     */
    protected void preRenderCallback(EntityZombie entitylivingbaseIn, float partialTickTime)
    {
        GlStateManager.scale(1.2F, 1.2F, 1.2F);
    }

    /**
     * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
     */
    protected ResourceLocation getEntityTexture(EntityZombie entity)
    {
        return BLIGHT_ZOMBIE_TEXTURES;
    }
    
    public class LayerBlightEyes implements LayerRenderer<EntityZombie>
    {
        private final RenderBlight endermanRenderer;

        public LayerBlightEyes(RenderBlight endermanRendererIn)
        {
            this.endermanRenderer = endermanRendererIn;
        }

        public void doRenderLayer(EntityZombie entitylivingbaseIn, float limbSwing, float limbSwingAmount, float partialTicks, float ageInTicks, float netHeadYaw, float headPitch, float scale)
        {
            GlStateManager.depthMask(!entitylivingbaseIn.isInvisible());
            this.endermanRenderer.bindTexture(new ResourceLocation(MoWithers.MODID, "textures/entity/mob/zombie_wither_eyes.png"));
            GlStateManager.enableBlend();
            GlStateManager.disableLighting();
            GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);
            GlStateManager.blendFunc(GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ONE);
            OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, 15728880.0F, 0);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(true);
            this.endermanRenderer.getMainModel().render(entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
            Minecraft.getMinecraft().entityRenderer.setupFogColor(false);
            this.endermanRenderer.setLightmap(entitylivingbaseIn);
            GlStateManager.enableLighting();
            GlStateManager.disableBlend();
        }

        public boolean shouldCombineTextures()
        {
            return false;
        }
    }
}