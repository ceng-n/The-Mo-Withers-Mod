package net.endermanofdoom.mowithers.entity.wither;

import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.EnumSkyBlock;
import net.minecraft.world.World;

public abstract class EntityHostileWither extends EntityBaseWither implements IMob
{
    public EntityHostileWither(World worldIn)
    {
        super(worldIn);
    }

    public SoundCategory getSoundCategory()
    {
        return SoundCategory.HOSTILE;
    }
    
    /**
     * Used by the Superbosses to prevent peaceful despawning.
     */
    public boolean isSuperBoss()
    {
    	return false;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (!this.world.isRemote && this.world.getDifficulty() == EnumDifficulty.PEACEFUL && !isSuperBoss() && !this.isRaidBoss() && !this.isTamed() && !this.isViticus())
        {
            this.setDead();
        }
        
        EntityPlayer player = world.getClosestPlayerToEntity(this, -1);
        
        if (!this.world.isRemote && !this.isMovementBlocked() && this.world.getDifficulty() == EnumDifficulty.HARD && !this.isTamed() && player != null && !player.capabilities.disableDamage)
        {
            this.setAttackTarget(player);
        	for (int i = 0; i < 2; ++i)
        	{
        		if (world.getEntityByID(this.getWatchedTargetId(i)) != player)
              		this.updateWatchedTargetId(i, player.getEntityId());
        	}
        }
    }

    protected SoundEvent getSwimSound()
    {
        return SoundEvents.ENTITY_HOSTILE_SWIM;
    }

    protected SoundEvent getSplashSound()
    {
        return SoundEvents.ENTITY_HOSTILE_SPLASH;
    }

    public float getBlockPathWeight(BlockPos pos)
    {
        return 0.5F - this.world.getLightBrightness(pos);
    }

    /**
     * Checks to make sure the light is not too bright where the mob is spawning
     */
    protected boolean isValidLightLevel()
    {
        BlockPos blockpos = new BlockPos(this.posX, this.getEntityBoundingBox().minY, this.posZ);

        if (this.world.getLightFor(EnumSkyBlock.SKY, blockpos) > this.rand.nextInt(32))
        {
            return false;
        }
        else
        {
            int i = this.world.getLightFromNeighbors(blockpos);

            if (this.world.isThundering())
            {
                int j = this.world.getSkylightSubtracted();
                this.world.setSkylightSubtracted(10);
                i = this.world.getLightFromNeighbors(blockpos);
                this.world.setSkylightSubtracted(j);
            }

            return i <= this.rand.nextInt(8);
        }
    }

    /**
     * Checks if the entity's current position is a valid location to spawn this entity.
     */
    public boolean getCanSpawnHere()
    {
        return this.world.getDifficulty() != EnumDifficulty.PEACEFUL && this.isValidLightLevel() && super.getCanSpawnHere();
    }

    /**
     * Entity won't drop items or experience points if this returns false
     */
    protected boolean canDropLoot()
    {
        return true;
    }

    public boolean isPreventingPlayerRest(EntityPlayer playerIn)
    {
        return true;
    }
}