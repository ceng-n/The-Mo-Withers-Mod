package net.endermanofdoom.mowithers.entity.wither;

public enum EnumWitherType 
{
	BLOCK_ROCK,
	BLOCK_WOOD,
	BLOCK_SOFT,
	MOB,
	FRIENDLY,
	QUEST,
	DEFAULT;
}
