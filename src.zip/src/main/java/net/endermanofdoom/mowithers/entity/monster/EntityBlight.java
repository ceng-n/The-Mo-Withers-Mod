package net.endermanofdoom.mowithers.entity.monster;

import javax.annotation.Nullable;

import net.endermanofdoom.mowithers.MoWithers;
import net.endermanofdoom.mowithers.entity.wither.EntityWitherSkullShared;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAIMoveThroughVillage;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;

public class EntityBlight extends EntityZombie implements IRangedAttackMob
{
	public EntityBlight(World worldIn) 
	{
		super(worldIn);
		this.isImmuneToFire = true;
        this.setSize(0.7F, 2.4F);
        this.experienceValue = 10;
        this.setPathPriority(PathNodeType.LAVA, 8F);
        this.setPathPriority(PathNodeType.DANGER_FIRE, 0F);
        this.setPathPriority(PathNodeType.DAMAGE_FIRE, 0F);
	}

    protected void applyEntityAI()
    {
        this.tasks.addTask(6, new EntityAIMoveThroughVillage(this, 1.0D, false));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[0]));
        this.targetTasks.addTask(2, new EntityAINearestAttackableTarget<EntityLivingBase>(this, EntityLivingBase.class, 0, false, false, MoWithers.NON_WITHER_OR_NETHER_MOB));
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(40.0D);
        this.getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(5.0D);
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(7D);
        this.getEntityAttribute(SPAWN_REINFORCEMENTS_CHANCE).setBaseValue(0D);
    }

    public boolean attackEntityAsMob(Entity entityIn)
    {
        if (!super.attackEntityAsMob(entityIn))
        {
            return false;
        }
        else
        {
            if (entityIn instanceof EntityLivingBase)
            {
                ((EntityLivingBase)entityIn).addPotionEffect(new PotionEffect(MobEffects.WITHER, 200, 1));
            }

            return true;
        }
    }
    
    /**
     * This method gets called when the entity kills another one.
     */
    public void onKillEntity(EntityLivingBase entityLivingIn)
    {
        super.onKillEntity(entityLivingIn);
        
        MoWithers.onKillEntity(this, entityLivingIn);
    }
    
    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        if (this.isEntityAlive())
        {
        	if (this.getAttackTarget() != null && (this.ticksExisted + this.getEntityId()) % 60 == 0 && this.getDistance(getAttackTarget()) > width && this.getDistance(getAttackTarget()) <= 20D)
        	{
        		this.attackEntityWithRangedAttack(getAttackTarget(), 0);
        	}
        	
            if (this.ticksExisted % 60 == 0)
            {
                this.heal(1.0F);
            }
            
            this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, this.posX + (this.rand.nextDouble() - 0.5D) * (double)this.width, this.posY + this.rand.nextDouble() * (double)this.height, this.posZ + (this.rand.nextDouble() - 0.5D) * (double)this.width, 0.0D, 0.0D, 0.0D);
        }

        super.onUpdate();
    }

    /**
     * Returns whether this Entity is on the same team as the given Entity.
     */
    public boolean isOnSameTeam(Entity entityIn)
    {
        if (super.isOnSameTeam(entityIn))
        {
            return true;
        }
        else if (entityIn instanceof EntityLivingBase && MoWithers.isWitherMob((EntityLivingBase)entityIn))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        if (source == DamageSource.WITHER)
        {
          this.heal(amount);
          return false;
        }
        else
        {
        	if (source.getTrueSource() != null && source.getTrueSource() instanceof EntityLivingBase && MoWithers.isWitherMob((EntityLivingBase)source.getTrueSource()))
        		return false;
        	
        	return super.attackEntityFrom(source, amount);
        }
    }
    
    public void attackEntityWithRangedAttack(EntityLivingBase target, float distanceFactor)
    {
        this.world.playEvent((EntityPlayer)null, 1024, new BlockPos(this), 0);
        double d0 = this.posX;
        double d1 = this.posY + this.getEyeHeight();
        double d2 = this.posZ;
        double d3 = target.posX - d0;
        double d4 = (target.posY + 0.4D) - d1;
        double d5 = target.posZ - d2;
        EntityWitherSkullShared skull = new EntityWitherSkullShared(this.world, this, d3, d4, d5);
        skull.setDamage(6F);
        skull.setRadius(0F);
        skull.posY = d1;
        skull.posX = d0;
        skull.posZ = d2;
        skull.noClip = true;
        skull.setSkullTexture("wither");
        this.world.spawnEntity(skull);
        this.swingArm(EnumHand.MAIN_HAND);
    }

	public void setSwingingArms(boolean swingingArms) {}
    
    @Nullable
    protected ResourceLocation getLootTable()
    {
        return LootTableList.ENTITIES_WITHER_SKELETON;
    }

    protected SoundEvent getAmbientSound()
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_SKELETON_AMBIENT, this.getSoundVolume() * 0.5F, this.getSoundPitch() + 0.1F);
        return SoundEvents.ENTITY_HUSK_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSourceIn)
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_HURT, this.getSoundVolume() * 0.5F, this.getSoundPitch() + 0.1F);
        return SoundEvents.ENTITY_HUSK_HURT;
    }

    protected SoundEvent getDeathSound()
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_DEATH, this.getSoundVolume() * 0.5F, this.getSoundPitch() + 0.1F);
        return SoundEvents.ENTITY_HUSK_DEATH;
    }

    protected SoundEvent getStepSound()
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_SKELETON_STEP, this.getSoundVolume() * 0.5F, this.getSoundPitch());
        return SoundEvents.ENTITY_HUSK_STEP;
    }
    
    public float getEyeHeight()
    {
        return super.getEyeHeight() * 1.2F;
    }
}
