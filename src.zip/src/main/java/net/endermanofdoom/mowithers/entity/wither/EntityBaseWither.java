package net.endermanofdoom.mowithers.entity.wither;

import com.google.common.base.Optional;
import com.google.common.base.Predicate;
import com.google.common.base.Predicates;

import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.endermanofdoom.mac.enums.EnumGender;
import net.endermanofdoom.mac.enums.EnumLevel;
import net.endermanofdoom.mac.interfaces.*;
import net.endermanofdoom.mac.util.math.Maths;
import net.endermanofdoom.mowithers.MoWithers;
import net.endermanofdoom.mowithers.registry.MItems;
import net.endermanofdoom.mowithers.registry.MSounds;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IEntityOwnable;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.entity.ai.EntityAIWanderAvoidWaterFlying;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.ai.EntityFlyHelper;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.RangedAttribute;
import net.minecraft.entity.boss.EntityWither;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityArrow;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemAxe;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemPickaxe;
import net.minecraft.item.ItemSpade;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.pathfinding.PathNavigate;
import net.minecraft.pathfinding.PathNavigateFlying;
import net.minecraft.potion.PotionEffect;
import net.minecraft.scoreboard.Team;
import net.minecraft.server.management.PreYggdrasilConverter;
import net.minecraft.util.CombatRules;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EntityDamageSource;
import net.minecraft.util.EntitySelectors;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.util.text.translation.I18n;
import net.minecraft.world.BossInfo;
import net.minecraft.world.BossInfoServer;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SuppressWarnings("deprecation")
public class EntityBaseWither extends EntityCreature implements IRangedAttackMob, IGendered, IMobTier, IVariedMob, IEntityOwnable
{
    private static final DataParameter<Integer> FIRST_HEAD_TARGET = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> SECOND_HEAD_TARGET = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> THIRD_HEAD_TARGET = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> FOURTH_HEAD_TARGET = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> FIFTH_HEAD_TARGET = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    @SuppressWarnings("unchecked")
	private static final DataParameter<Integer>[] HEAD_TARGETS = new DataParameter[] {FIRST_HEAD_TARGET, SECOND_HEAD_TARGET, THIRD_HEAD_TARGET, FOURTH_HEAD_TARGET, FIFTH_HEAD_TARGET};
    private static final DataParameter<Integer> INVULNERABILITY_TIME = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> RAM_TIME = EntityDataManager.<Integer>createKey(EntityBaseWither.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> RAID_VERSION = EntityDataManager.<Boolean>createKey(EntityBaseWither.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> IS_VITICUS = EntityDataManager.<Boolean>createKey(EntityBaseWither.class, DataSerializers.BOOLEAN);
    protected static final DataParameter<Byte> TAMED = EntityDataManager.<Byte>createKey(EntityBaseWither.class, DataSerializers.BYTE);
    protected static final DataParameter<Optional<UUID>> OWNER_UNIQUE_ID = EntityDataManager.<Optional<UUID>>createKey(EntityBaseWither.class, DataSerializers.OPTIONAL_UNIQUE_ID);
    private static final IAttribute CURRENT_HEALTH_WITHER = (new RangedAttribute((IAttribute)null, "wither.currentHealth", 300.0D, 0D, Double.MAX_VALUE)).setDescription("Current Health").setShouldWatch(true);
    protected static final IAttribute MAX_HEALTH_WITHER = (new RangedAttribute((IAttribute)null, "wither.maxHealth", 300.0D, 0D, Double.MAX_VALUE)).setDescription("Max Health").setShouldWatch(true);
    private final float[] xRotationHeads = new float[4];
    private final float[] yRotationHeads = new float[4];
    private final float[] xRotOHeads = new float[4];
    private final float[] yRotOHeads = new float[4];
    private final int[] nextHeadUpdate = new int[4];
    private final int[] idleHeadUpdates = new int[4];
    /** Time before the Wither tries to break blocks */
    protected int blockBreakCounter;
    protected int switchhoverposCounter;
    protected int switchAI;
    protected EntityAIWitherStay aiSit;
    public int deathTicks;
    protected BossInfoServer bossInfo = (BossInfoServer)(new BossInfoServer(this.getDisplayName(), BossInfo.Color.PURPLE, BossInfo.Overlay.PROGRESS)).setDarkenSky(true);
    protected double flyposX;
    protected double flyposZ;
    protected int shouldUseDynamicAI;
    protected int maxCharges;
    /** Selector used to determine the entities a wither boss should attack. */
    protected static Predicate<Entity> WITHERTARGETS = new Predicate<Entity>()
    {
        public boolean apply(@Nullable Entity p_apply_1_)
        {
            return p_apply_1_ instanceof EntityLivingBase && ((EntityLivingBase)p_apply_1_).attackable();
        }
    };
    private float clientSideStandAnimation0;
    private float clientSideStandAnimation;

    public EntityBaseWither(World worldIn)
    {
        super(worldIn);
        this.isImmuneToFire = true;
        this.experienceValue = 500;
        this.stepHeight = 2F;
        this.moveHelper = new EntityFlyHelper(this);
        this.tasks.addTask(0, new EntityBaseWither.AIDoNothing());
        this.ignoreFrustumCheck = true;
    }

	protected void initEntityAI()
    {
        this.tasks.addTask(1, new EntityAISwimming(this));
        this.tasks.addTask(3, new EntityAIWitherShoot(this));
        this.tasks.addTask(4, new EntiyAIWitherFollowOwner(this, 1.0D, 32.0F, 2.0F));
        this.tasks.addTask(5, new EntityAIWanderAvoidWaterFlying(this, 1.0D));
        this.tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(7, new EntityAILookIdle(this));
        this.targetTasks.addTask(0, new EntityAIWitherOwnerHurtByTarget(this));
        this.targetTasks.addTask(2, new EntityAIWitherOwnerHurtTarget(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[0]));
    }

    /**
     * Returns new PathNavigateGround instance
     */
    protected PathNavigate createNavigator(World worldIn)
    {
        PathNavigateFlying pathnavigateflying = new PathNavigateFlying(this, worldIn);
        pathnavigateflying.setCanOpenDoors(false);
        pathnavigateflying.setCanFloat(true);
        pathnavigateflying.setCanEnterDoors(true);
        return pathnavigateflying;
    }

    protected void entityInit()
    {
        super.entityInit();
        this.dataManager.register(FIRST_HEAD_TARGET, Integer.valueOf(0));
        this.dataManager.register(SECOND_HEAD_TARGET, Integer.valueOf(0));
        this.dataManager.register(THIRD_HEAD_TARGET, Integer.valueOf(0));
        this.dataManager.register(FOURTH_HEAD_TARGET, Integer.valueOf(0));
        this.dataManager.register(FIFTH_HEAD_TARGET, Integer.valueOf(0));
        this.dataManager.register(INVULNERABILITY_TIME, Integer.valueOf(0));
        this.dataManager.register(RAM_TIME, Integer.valueOf(0));
        this.dataManager.register(TAMED, Byte.valueOf((byte)0));
        this.dataManager.register(OWNER_UNIQUE_ID, Optional.absent());
        this.dataManager.register(RAID_VERSION, Boolean.valueOf(false));
        this.dataManager.register(IS_VITICUS, Boolean.valueOf(false));
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(this.getMobSpeed() * 0.5D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64D);
        this.getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(4.0D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(this.getMobAttack());
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_SPEED).setBaseValue(40D);
        this.getAttributeMap().registerAttribute(SharedMonsterAttributes.FLYING_SPEED).setBaseValue(this.getMobSpeed() * 3D);
        this.getAttributeMap().registerAttribute(CURRENT_HEALTH_WITHER).setBaseValue(this.getMobHealth());
        this.getAttributeMap().registerAttribute(MAX_HEALTH_WITHER).setBaseValue(this.getMobHealth());
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(this.getMobHealth());
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (this.deathTime > 0 || this.deathTicks > 0)
            this.setHealth(0);
        else
        	this.setHealth((float)this.getWitherHealth());
        
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(this.getMaxWitherHealth());

        if (this.getRamTime() > 0)
    		this.renderYawOffset = this.rotationYaw = this.rotationYawHead;
        
        if (this.getRamTime() > 0 && this.getRamTime() < 40 && this.getWatchedTargetId(0) > 0 && world.getEntityByID(getWatchedTargetId(0)) != null)
        	this.faceEntity(this.world.getEntityByID(getWatchedTargetId(0)), 180F, 0);
        
        this.fallDistance *= 0;
        
        if (this.world.isRemote)
        {
            this.clientSideStandAnimation0 = this.clientSideStandAnimation;

            if (this.isCrouching())
            {
                this.clientSideStandAnimation = MathHelper.clamp(this.clientSideStandAnimation + (0.1F / this.getWitherScale()), 0.0F, 0.5F);
            }
            else if (!this.getNavigator().noPath())
            {
                this.clientSideStandAnimation = MathHelper.clamp(this.clientSideStandAnimation + (0.025F / this.getWitherScale()), 0.0F, 0.1F);
            }
            else
            {
                this.clientSideStandAnimation = MathHelper.clamp(this.clientSideStandAnimation - (0.1F / this.getWitherScale()), 0.0F, 0.5F);
            }
        }
        else
        {
            if (this.getInvulTime() > 0)
            {
                int j1 = this.getInvulTime() - 1;

                if (j1 <= 0)
                {
                    this.world.newExplosion(this, this.posX, this.posY + (double)this.getEyeHeight(), this.posZ, 7.0F * width, false, net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.world, this));
                    this.world.playBroadcastSound(1023, new BlockPos(this), 0);
                }

                this.setInvulTime(j1);
            }
        }
        
        this.bossInfo.setPercent((float)(this.getWitherHealth() / this.getMaxWitherHealth()));
        this.bossInfo.setName(this.getDisplayName());
    }

    /**
     * Heal living entity (param: amount of half-hearts)
     */
    public void heal(double healAmount)
    {
        double f = this.getWitherHealth();

        if (f > 0.0F)
        {
            this.setWitherHealth(f + healAmount);
        }
    }
    
    public void heal(float healAmount)
    {
        this.heal((double)healAmount);
    }

    public double getMaxWitherHealth()
    {
        return getEntityAttribute(MAX_HEALTH_WITHER).getAttributeValue();
    }

    public double getWitherHealth()
    {
        return getEntityAttribute(CURRENT_HEALTH_WITHER).getAttributeValue();
    }

    public void setWitherHealth(double health)
    {
    	this.setHealth((float)(health >= this.getMaxWitherHealth() ? this.getMaxWitherHealth() : (this.isArmored() && !this.isTamed() && health >= this.getMaxWitherHealth() / 2 ? this.getMaxWitherHealth() / 2 : health)));
        this.getEntityAttribute(CURRENT_HEALTH_WITHER).setBaseValue(health >= this.getMaxWitherHealth() ? this.getMaxWitherHealth() : (this.isArmored() && !this.isTamed() && health >= this.getMaxWitherHealth() / 2 ? this.getMaxWitherHealth() / 2 : health));
    }
    
    protected boolean isMovementBlocked()
    {
        return this.getInvulTime() > 0 || this.getWitherHealth() <= 0;
    }

    @SideOnly(Side.CLIENT)
    public float getStandingAnimationScale(float p_189795_1_)
    {
        return (this.clientSideStandAnimation0 + (this.clientSideStandAnimation - this.clientSideStandAnimation0) * p_189795_1_) / 0.65F;
    }
    
    public boolean isCrouching()
    {
        return this.isSitting() || this.isSneaking() || this.getRamTime() > 0;
    }
    
    public boolean canAttackClass(Class <? extends EntityLivingBase > cls)
    {
        return cls != this.getClass() || this.getOwner() != null && cls == this.getOwner().getClass();
    }
    
    public TextFormatting getNameColor()
    {
    	return TextFormatting.WHITE;
    }
    
    public String getName()
    {
    	String rb = "";
    	TextFormatting color = this.getNameColor();
    	
    	if (this.isRaidBoss())
    	{
    		color = TextFormatting.BOLD;
    		rb = " [RAID BOSS]";
    	}
    	
    	if (this.isViticus())
    	{
    		rb = " [" + I18n.translateToLocal("entity.cultist_leader_sec.name") + "]";
    	}
    	
    	return color + super.getName() + rb + TextFormatting.WHITE + " " + parseFloat(getWitherHealth() + this.getAbsorptionAmount());
    }
    
	private String parseFloat(double value)
	{
		String input;
		if (value >= 1000000000000000000000000000000000000.0D)
		input = "Infinity (" + (int)Math.floor((value / Double.MAX_VALUE) * 100) + "%)";
		else if (value >= 1000000000000000000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000000000000000000001D) * 0.1D + " Decillion";
		else if (value >= 1000000000000000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000000000000000001D) * 0.1D + " Nonillion";
		else if (value >= 1000000000000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000000000000001D) * 0.1D + " Octillion";
		else if (value >= 1000000000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000000000001D) * 0.1D + " Septillion";
		else if (value >= 1000000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000000001D) * 0.1D + " Sextillion";
		else if (value >= 1000000000000000000.0D)
		input = Math.floor(value * 0.00000000000000001D) * 0.1D + " Quintillion";
		else if (value >= 1000000000000000.0D)
		input = Math.floor(value * 0.00000000000001D) * 0.1D + " Quadrillion";
		else if (value >= 1000000000000.0D)
		input = Math.floor(value * 0.00000000001D) * 0.1D + " Trillion";
		else if (value >= 1000000000.0D)
		input = Math.floor(value * 0.00000001D) * 0.1D + " Billion";
		else if (value >= 1000000.0D)
		input =  Math.floor(value * 0.00001D) * 0.1D + " Million";
		else
		input = (int)Math.floor(value) + "";
		return input;
	}

    public boolean isRaidBoss()
    {
        return ((Boolean)this.dataManager.get(RAID_VERSION)).booleanValue();
    }

    public void setRaidBoss(boolean rb)
    {
        this.dataManager.set(RAID_VERSION, Boolean.valueOf(rb));
    }

    public boolean isViticus()
    {
        return ((Boolean)this.dataManager.get(IS_VITICUS)).booleanValue();
    }

    public void setIsViticus(boolean rb)
    {
        this.dataManager.set(IS_VITICUS, Boolean.valueOf(rb));
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound compound)
    {
        super.writeEntityToNBT(compound);
        compound.setInteger("Invul", this.getInvulTime());

        if (this.getOwnerId() == null)
        {
            compound.setString("OwnerUUID", "");
        }
        else
        {
            compound.setString("OwnerUUID", this.getOwnerId().toString());
        }

        compound.setBoolean("Sitting", this.isSitting());
        compound.setBoolean("RaidBoss", this.isRaidBoss());
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound compound)
    {
        super.readEntityFromNBT(compound);
        this.setInvulTime(compound.getInteger("Invul"));
        String s;

        if (compound.hasKey("OwnerUUID", 8))
        {
            s = compound.getString("OwnerUUID");
        }
        else
        {
            String s1 = compound.getString("Owner");
            s = PreYggdrasilConverter.convertMobOwnerIfNeeded(this.getServer(), s1);
        }

        if (!s.isEmpty())
        {
            try
            {
                this.setOwnerId(UUID.fromString(s));
                this.setTamed(true);
            }
            catch (Throwable var4)
            {
                this.setTamed(false);
            }
        }

        if (this.aiSit != null)
        {
            this.aiSit.setSitting(compound.getBoolean("Sitting"));
        }

        this.setSitting(compound.getBoolean("Sitting"));
        this.setRaidBoss(compound.getBoolean("RaidBoss"));
    }
    
    /**
     * Play the taming effect, will either be hearts or smoke depending on status
     */
    protected void playTameEffect(boolean play)
    {
        EnumParticleTypes enumparticletypes = EnumParticleTypes.SMOKE_LARGE;

        if (!play)
        {
            enumparticletypes = EnumParticleTypes.SUSPENDED;
        }

        for (int i = 0; i < 7; ++i)
        {
            double d0 = this.rand.nextGaussian() * 0.02D;
            double d1 = this.rand.nextGaussian() * 0.02D;
            double d2 = this.rand.nextGaussian() * 0.02D;
            this.world.spawnParticle(enumparticletypes, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + 0.5D + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d0, d1, d2);
        }
    }

    /**
     * Handler for {@link World#setEntityState}
     */
    @SideOnly(Side.CLIENT)
    public void handleStatusUpdate(byte id)
    {
        if (id == 7)
        {
            this.playTameEffect(true);
        }
        else if (id == 6)
        {
            this.playTameEffect(false);
        }
        else
        {
            super.handleStatusUpdate(id);
        }
    }

    public boolean isTamed()
    {
        return (((Byte)this.dataManager.get(TAMED)).byteValue() & 4) != 0;
    }

    public void setTamed(boolean tamed)
    {
        byte b0 = ((Byte)this.dataManager.get(TAMED)).byteValue();

        if (tamed)
        {
            this.dataManager.set(TAMED, Byte.valueOf((byte)(b0 | 4)));
        }
        else
        {
            this.dataManager.set(TAMED, Byte.valueOf((byte)(b0 & -5)));
        }

        this.setupTamedAI();
    }

    protected void setupTamedAI()
    {
    }

    public boolean isSitting()
    {
        return (((Byte)this.dataManager.get(TAMED)).byteValue() & 1) != 0;
    }

    public void setSitting(boolean sitting)
    {
        byte b0 = ((Byte)this.dataManager.get(TAMED)).byteValue();

        if (sitting)
        {
            this.dataManager.set(TAMED, Byte.valueOf((byte)(b0 | 1)));
        }
        else
        {
            this.dataManager.set(TAMED, Byte.valueOf((byte)(b0 & -2)));
        }
    }

    @SuppressWarnings("rawtypes")
	@Nullable
    public UUID getOwnerId()
    {
        return (UUID)((Optional)this.dataManager.get(OWNER_UNIQUE_ID)).orNull();
    }

    public void setOwnerId(@Nullable UUID p_184754_1_)
    {
        this.dataManager.set(OWNER_UNIQUE_ID, Optional.fromNullable(p_184754_1_));
    }

    public void setTamedBy(EntityPlayer player)
    {
        this.setTamed(true);
        this.setOwnerId(player.getUniqueID());
    }

    @Nullable
    public EntityLivingBase getOwner()
    {
        try
        {
            UUID uuid = this.getOwnerId();
            return uuid == null ? null : this.world.getPlayerEntityByUUID(uuid);
        }
        catch (IllegalArgumentException var2)
        {
            return null;
        }
    }

    public boolean isOwner(EntityLivingBase entityIn)
    {
        return this.getOwner() != null && entityIn == this.getOwner();
    }

    /**
     * Returns the AITask responsible of the sit logic
     */
    public EntityAIWitherStay getAISit()
    {
        return this.aiSit;
    }

    public boolean shouldAttackEntity(EntityLivingBase target, EntityLivingBase owner)
    {
        return true;
    }

    public Team getTeam()
    {
        if (this.isTamed())
        {
            EntityLivingBase entitylivingbase = this.getOwner();

            if (entitylivingbase != null)
            {
                return entitylivingbase.getTeam();
            }
        }

        return super.getTeam();
    }

    /**
     * Returns whether this Entity is on the same team as the given Entity.
     */
    public boolean isOnSameTeam(Entity entityIn)
    {
        if (this.isTamed())
        {
            EntityLivingBase entitylivingbase = this.getOwner();

            if (entityIn == entitylivingbase)
            {
                return true;
            }

            if (entityIn instanceof EntityBaseWither && ((EntityBaseWither)entityIn).getOwner() == entitylivingbase)
                return true;
            
            if (entityIn instanceof IMob)
                return false;
            else if (entitylivingbase != null && entityIn != entitylivingbase.getLastAttackedEntity() && entityIn != entitylivingbase.getRevengeTarget())
            	return true;
            
            if (entitylivingbase != null)
            {
                return entitylivingbase.isOnSameTeam(entityIn);
            }
        }
        
        if (entityIn == this)
        {
            return true;
        }
        
        if (entityIn.getClass() == this.getClass())
        {
            return true;
        }
        
        if (entityIn instanceof EntityLivingBase && this.isViticus() && MoWithers.isWitherMob((EntityLivingBase)entityIn))
        {
            return true;
        }
        
        return super.isOnSameTeam(entityIn);
    }

    /**
     * Deals damage to the entity. This will take the armor of the entity into consideration before damaging the health
     * bar.
     */
    protected void damageEntity(DamageSource damageSrc, float damageAmount)
    {
        if (!this.isEntityInvulnerable(damageSrc))
        {
            damageAmount = net.minecraftforge.common.ForgeHooks.onLivingHurt(this, damageSrc, damageAmount);
            if (damageAmount <= 0) return;
            damageAmount = this.applyArmorCalculations(damageSrc, damageAmount);
            damageAmount = this.applyPotionDamageCalculations(damageSrc, damageAmount);
            float f = damageAmount;
            damageAmount = Math.max(damageAmount - this.getAbsorptionAmount(), 0);
            this.setAbsorptionAmount(this.getAbsorptionAmount() - (f - damageAmount));
            damageAmount = net.minecraftforge.common.ForgeHooks.onLivingDamage(this, damageSrc, damageAmount);

            if (damageAmount != 0.0F)
            {
                double f1 = this.getWitherHealth();
                this.getCombatTracker().trackDamage(damageSrc, (float) f1, damageAmount);
                this.setWitherHealth(f1 - damageAmount);
                this.setAbsorptionAmount(this.getAbsorptionAmount() - damageAmount);
                if (this.rand.nextInt(6) == 0)
                	this.shouldUseDynamicAI = rand.nextInt();
                if (this.rand.nextInt(3) == 0)
                	this.switchhoverposCounter = (isRaidBoss() ? 60 : 200);
            }
        }
    }

    /**
     * Reduces damage, depending on armor
     */
    protected float applyArmorCalculations(DamageSource source, float damage)
    {
    	if (damage > 0F)
        damage = CombatRules.getDamageAfterAbsorb(damage, (float)this.getTotalArmorValue(), (float)this.getEntityAttribute(SharedMonsterAttributes.ARMOR_TOUGHNESS).getAttributeValue());

        return damage;
    }
    
    /**
     * Called when the mob's health reaches 0.
     */
    public void onDeath(DamageSource cause)
    {
        if (!this.world.isRemote && this.world.getGameRules().getBoolean("showDeathMessages") && this.getOwner() instanceof EntityPlayerMP)
        {
            this.getOwner().sendMessage(this.getCombatTracker().getDeathMessage());
        }

        super.onDeath(cause);
    }

    /**
     * Sets the custom name tag for this entity
     */
    public void setCustomNameTag(String name)
    {
        super.setCustomNameTag(name);
        this.bossInfo.setName(this.getDisplayName());
    }

    public float getBaseWidth()
    {
    	return this.deathTime > 0 ? 0.9F : 0.45F;
    }

    public float getBaseHeight()
    {
    	return this.deathTime > 0 ? 0.5F : this.isCrouching() ? 1.0F : 1.75F;
    }

    public float getWitherScale()
    {
    	return this.isRaidBoss() ? 8F : 2F;
    }
    
    protected SoundEvent getAmbientSound()
    {
        return SoundEvents.ENTITY_WITHER_AMBIENT;
    }

    protected SoundEvent getHurtSound(DamageSource damageSourceIn)
    {
        return SoundEvents.ENTITY_WITHER_HURT;
    }

    protected SoundEvent getDeathSound()
    {
        return SoundEvents.ENTITY_WITHER_DEATH;
    }
    
    protected float getSoundVolume()
    {
      return this.getWitherScale() * 3F;
    }
    
    protected double getFlyHeight()
    {
        return 5D;
    }
    
    public void onWitherMoveUpdate()
    {
    	if (!this.isArmored() || motionY > 0)
        this.motionY *= 0.6D;
        
    	if (!this.world.isRemote)
        if (this.getWatchedTargetId(0) > 0)
        {
            Entity entity = this.world.getEntityByID(this.getWatchedTargetId(0));

            if (entity != null)
            {
            	this.getNavigator().clearPath();
            	
            	if (this.world.getEntityByID(this.getWatchedTargetId(1)) == null && rand.nextInt(40) == 0)
            		this.updateWatchedTargetId(1, entity.getEntityId());
            	
            	if (this.world.getEntityByID(this.getWatchedTargetId(2)) == null && rand.nextInt(40) == 0)
            		this.updateWatchedTargetId(2, entity.getEntityId());
            	
            	if (entity instanceof EntityWither || entity instanceof EntityBaseWither || this.isRaidBoss())
            	{
              	  for (int i = 0; i < 8; i++)
                  {
            		  int in = MathHelper.floor(this.posX - 1.5D + this.rand.nextDouble() * 3.0D);
            		  int j = MathHelper.floor(this.posY + 3.0D - this.rand.nextDouble() * (this.isArmored() ? 4 : 4 + getFlyHeight()));
            		  int k = MathHelper.floor(this.posZ - 1.5D + this.rand.nextDouble() * 3.0D);
            		  BlockPos blockpos = new BlockPos(in, j, k);
            		  IBlockState iblockstate = this.world.getBlockState(blockpos);
            		  if (!this.world.isRemote && (iblockstate.isFullCube() || blockpos.getY() <= 0))
           	         {
           	          if (this.motionY < 0.0D)
           	            this.motionY = 0.0D;
           	          
           	          this.motionY += (0.5D - this.motionY) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() / 3);
                    }
                  }
            	}
              	  else
              	  {

                      if (this.posY < entity.posY || !this.isArmored() && this.posY < entity.posY + getFlyHeight() && this.posY < 255 - height)
                      {
                          if (this.motionY < 0.0D)
                          {
                              this.motionY = 0.0D;
                          }

                          this.motionY += (0.5D - this.motionY) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() / 3);
                      }
              	  }
            	
                if (this.getRamTime() < 0 || this.isArmored() || this.isSuperBoss())
                	this.setRamTime(getRamTime() + 1);

                if (this.shouldUseDynamicAI != 1)
                {
                	flyposX = entity.posX;
                	flyposZ = entity.posZ;
                	switchhoverposCounter = (isRaidBoss() ? 60 : 200);
                }
                else
                {
                    if (++this.switchhoverposCounter >= (isRaidBoss() ? 60 : 200))
                    {
                    	flyposX = entity.posX + (double)((rand.nextFloat() * 2.0F - 1.0F) * (6 * this.getWitherScale()));
                    	flyposZ = entity.posZ + (double)((rand.nextFloat() * 2.0F - 1.0F) * (6 * this.getWitherScale()));
                    	switchhoverposCounter = 0;
                    }
                }
                
                double d0 = this.flyposX - this.posX;
                double d1 = this.flyposZ - this.posZ;
                
                
                double d3 = d0 * d0 + d1 * d1;
                
                double movereduc = (this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? 0.5D : 0.33D);
                
                if (world.getDifficulty() == EnumDifficulty.EASY)
                	movereduc *= 0.75D;
                
                if (world.getDifficulty() == EnumDifficulty.HARD)
                	movereduc *= 1.5D;
                
                if (this.getRamTime() > 0)
                {
                	if (this.getRamTime() <= 60)
                	{
                		this.rotationPitch = 0;
                		if (this.motionY > 0)
                		this.motionY = 0;
                        double d4 = entity.posX - this.posX;
                        double d5 = entity.posZ - this.posZ;
                        if (this.getRamTime() <= 30)
                		renderYawOffset = rotationYaw = rotationYawHead = (float)(MathHelper.atan2(d5, d4) * (180D / Math.PI)) - 90.0F;
                        Vec3d vec3d = this.getLook(1.0F);
                        flyposX = (this.posX + vec3d.x * (16 * this.getWitherScale()));
                        flyposZ = (this.posZ + vec3d.z * (16 * this.getWitherScale()));
                	}
                	else
                	{
                        double ramspeedmul = (this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? 2D : 1D);
                        
                        if (world.getDifficulty() == EnumDifficulty.EASY)
                        	ramspeedmul *= 0.75D;
                        
                        if (world.getDifficulty() == EnumDifficulty.HARD)
                        	ramspeedmul *= 1.5D;
                		
                		this.blockBreakCounter = 1;
                        this.breakBlocks(-((int)width + 3), (int)width + 3, -5, (int)height + 3, -((int)width + 3), (int)width + 3);
                        if (d3 > 6D && !this.collidedHorizontally)
                        {
                            renderYawOffset = rotationYaw = rotationYawHead = (float)MathHelper.atan2(this.motionZ, this.motionX) * (180F / (float)Math.PI) - 90.0F;
                            if (this.posY < entity.posY - 1D)
                                this.motionY += (0.75D - this.motionY) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() * movereduc);
                            
                            double d5 = (double)MathHelper.sqrt(d3);
                            this.motionX += (d0 / d5 * ramspeedmul - this.motionX) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() * movereduc);
                            this.motionZ += (d1 / d5 * ramspeedmul - this.motionZ) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() * movereduc);
                            
                            List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().grow(width + 4));

                            for (Entity entity1 : list)
                            {
                                if (entity1.isEntityAlive() && !this.isOnSameTeam(entity1) && entity1 instanceof EntityLivingBase && entity1.hurtResistantTime <= 10)
                                {
                                	entity1.attackEntityFrom(DamageSource.causeMobDamage(this), (float)(getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getBaseValue() * (this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? 4 : 2)));
                                }
                            }
                        }
                        else
                        {
                            if (collidedHorizontally)
                                this.world.newExplosion(this, this.posX, this.posY + (double)this.getEyeHeight(), this.posZ, 7.0F * width, false, net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.world, this));
                        	
                            if (this.maxCharges < (this.getMaxWitherHealth() / this.getWitherHealth() >= 10 ? 10 : this.getMaxWitherHealth() / this.getWitherHealth()))
                            {
                            	++this.maxCharges;
                            	this.setRamTime(this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? 58 : 55);
                                double d4 = entity.posX - this.posX;
                                double d5 = entity.posZ - this.posZ;
                        		renderYawOffset = rotationYaw = rotationYawHead = (float)(MathHelper.atan2(d5, d4) * (180D / Math.PI)) - 90.0F;
                            }
                            else
                            {
                                this.setRamTime(this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? -100 : (!this.isArmored() ? -1000 : -200));
                                this.maxCharges = 0;
                            }
                        }
                	}
                }
                else
                {
                    if (d3 > (this.isArmored() ? 64D : 16D) + width + entity.width)
                    {
                        double d5 = (double)MathHelper.sqrt(d3);
                        this.motionX += (d0 / d5 * 0.5D - this.motionX) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() * movereduc);
                        this.motionZ += (d1 / d5 * 0.5D - this.motionZ) * (getEntityAttribute(SharedMonsterAttributes.FLYING_SPEED).getBaseValue() * movereduc);
                        this.setSneaking(true);
                    }
                    else
                        this.setSneaking(false);
                    
                    if (!this.canEntityBeSeen(entity) && this.ticksExisted % 200 == 0)
                        this.launchWitherSkullToEntity(0, (EntityLivingBase)entity);
                }
            }
        }
        else
        {
            this.setSneaking(false);
        	flyposX = posX;
        	flyposZ = posZ;
        	switchhoverposCounter = (isRaidBoss() ? 60 : 200);
        	this.noClip = false;
            if (this.getRamTime() > 0)
            	this.setRamTime(getRamTime() - 1);
        }

        if (this.motionX * this.motionX + this.motionZ * this.motionZ != 0D && this.getRamTime() <= 0)
        {
            renderYawOffset = rotationYaw = (float)MathHelper.atan2(this.motionZ, this.motionX) * (180F / (float)Math.PI) - 90.0F;
        }
    }
    
    public void onWitherParticaleUpdate()
    {
        boolean flag = this.isArmored();

        for (int l = 0; l < this.getHeadCount(); ++l)
        {
            double d10 = this.getHeadX(l);
            double d2 = this.getHeadY(l);
            double d4 = this.getHeadZ(l);
            this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, d10 + this.rand.nextGaussian() * 0.30000001192092896D, d2 + this.rand.nextGaussian() * 0.30000001192092896D, d4 + this.rand.nextGaussian() * 0.30000001192092896D, 0.0D, 0.0D, 0.0D);

            if (flag && this.world.rand.nextInt(4) == 0)
            {
                this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, d10 + this.rand.nextGaussian() * 0.30000001192092896D, d2 + this.rand.nextGaussian() * 0.30000001192092896D, d4 + this.rand.nextGaussian() * 0.30000001192092896D, 0.699999988079071D, 0.699999988079071D, 0.5D);
            }
        }

        if (this.getInvulTime() > 0)
        {
            for (int i1 = 0; i1 < 3; ++i1)
            {
                this.world.spawnParticle(EnumParticleTypes.SPELL_MOB, this.posX + this.rand.nextGaussian(), this.posY + (double)(this.rand.nextFloat() * 3.3F), this.posZ + this.rand.nextGaussian(), 0.699999988079071D, 0.699999988079071D, 0.8999999761581421D);
            }
        }
    }
    
    public void onWitherTargetUpdate()
    {
        for (int i = 1; i < getHeadCount(); ++i)
        {
            if (this.ticksExisted >= this.nextHeadUpdate[i - 1])
            {
                this.nextHeadUpdate[i - 1] = this.ticksExisted + 10 + this.rand.nextInt(10);

                if (this.world.getDifficulty() == EnumDifficulty.NORMAL || this.world.getDifficulty() == EnumDifficulty.HARD)
                {
                    int j3 = i - 1;
                    int k3 = this.idleHeadUpdates[i - 1];
                    this.idleHeadUpdates[j3] = this.idleHeadUpdates[i - 1] + 1;

                    if (k3 > 15)
                    {
                        float f = 10.0F * width;
                        float f1 = 5.0F;
                        double d0 = MathHelper.nextDouble(this.rand, this.posX - f, this.posX + f);
                        double d1 = MathHelper.nextDouble(this.rand, this.posY - f1, this.posY + f1);
                        double d2 = MathHelper.nextDouble(this.rand, this.posZ - f, this.posZ + f);
                        this.launchWitherSkullToCoords(i + 1, d0, d1, d2, true);
                        this.idleHeadUpdates[i - 1] = 0;
                    }
                }

                int k1 = this.getWatchedTargetId(i);

                if (k1 > 0)
                {
                    Entity entity = this.world.getEntityByID(k1);

                    if ((getRamTime() <= 0 || this.getWitherHealth() <= this.getMaxWitherHealth()) && entity != null && entity.isEntityAlive() && entity instanceof EntityLivingBase && !this.isOnSameTeam(entity) && this.getDistance(entity) <= getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getBaseValue() && (this.canEntityBeSeen(entity) || this.noClip) && !entity.getIsInvulnerable())
                    {
                        if (entity instanceof EntityPlayer && ((EntityPlayer)entity).capabilities.disableDamage)
                        {
                            this.updateWatchedTargetId(i, 0);
                        }
                        else
                        {
                            this.launchWitherSkullToEntity(i + 1, (EntityLivingBase)entity);
                            this.nextHeadUpdate[i - 1] = this.ticksExisted + (int)getEntityAttribute(SharedMonsterAttributes.ATTACK_SPEED).getBaseValue() + rand.nextInt(10);
                            this.idleHeadUpdates[i - 1] = 0;
                        }
                    }
                    else
                    {
                        this.updateWatchedTargetId(i, 0);
                    }
                }
                else
                {
                    List<EntityLivingBase> list = this.world.<EntityLivingBase>getEntitiesWithinAABB(EntityLivingBase.class, this.getEntityBoundingBox().grow(getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getBaseValue()), Predicates.and(WITHERTARGETS, EntitySelectors.NOT_SPECTATING));

                    for (int j2 = 0; j2 < 50 && !list.isEmpty(); ++j2)
                    {
                        EntityLivingBase entitylivingbase = list.get(this.rand.nextInt(list.size()));

                        if (getRamTime() <= 0 && entitylivingbase != this && entitylivingbase.isEntityAlive() && !entitylivingbase.getIsInvulnerable() && !this.isOnSameTeam(entitylivingbase) && this.getDistance(entitylivingbase) <= getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getBaseValue() && entitylivingbase.isEntityAlive() && (this.canEntityBeSeen(entitylivingbase) || this.noClip))
                        {
                            if (entitylivingbase instanceof EntityPlayer)
                            {
                                if (!((EntityPlayer)entitylivingbase).capabilities.disableDamage)
                                {
                                    this.updateWatchedTargetId(i, entitylivingbase.getEntityId());
                                }
                            }
                            else
                            {
                                this.updateWatchedTargetId(i, entitylivingbase.getEntityId());
                            }

                            break;
                        }

                        list.remove(entitylivingbase);
                    }
                }
            }
        }
    }
    
    public void onHealUpdate()
    {
        if (this.ticksExisted % 20 == 0)
        {
            this.heal(1.0D);
        }
    }
    
    public void addVelocity(double x, double y, double z) 
    {
    	if (!this.isSuperBoss() && !this.isRaidBoss() && !this.noClip)
    		super.addVelocity(x, y, z);
    }
    
    public void setDead() 
    {
    	if (!this.isSuperBoss() || this.world.isRemote)
    	{
    		super.setDead();            
    		for (int i = 0; i < this.width + this.height * 20; ++i)
            {
                double d0 = (double)((float)this.getPosition().getX() + this.world.rand.nextFloat());
                double d1 = (double)((float)this.getPosition().getY() + this.world.rand.nextFloat());
                double d2 = (double)((float)this.getPosition().getZ() + this.world.rand.nextFloat());
                double d3 = d0 - posX;
                double d4 = d1 - posY;
                double d5 = d2 - posZ;
                double d6 = (double)MathHelper.sqrt(d3 * d3 + d4 * d4 + d5 * d5);
                d3 = d3 / d6;
                d4 = d4 / d6;
                d5 = d5 / d6;
                double d7 = 0.5D / (d6 / (double)this.height + 0.1D);
                d7 = d7 * (double)(this.world.rand.nextFloat() * this.world.rand.nextFloat() + 0.3F);
                d3 = d3 * d7;
                d4 = d4 * d7;
                d5 = d5 * d7;
                this.world.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, (d0 + posX) / 2.0D, (d1 + posY + this.getEyeHeight()) / 2.0D, (d2 + posZ) / 2.0D, d3, d4, d5);
                this.world.spawnParticle(EnumParticleTypes.SMOKE_NORMAL, (d0 + posX) / 2.0D, (d1 + posY + this.getEyeHeight()) / 2.0D, (d2 + posZ) / 2.0D, d3, d4, d5);
                this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, d0, d1, d2, d3, d4, d5);
            }
    	}
    }

    /**
     * Called frequently so the entity can update its state every tick as required. For example, zombies and skeletons
     * use this to react to sunlight and start to burn.
     */
    public void onLivingUpdate()
    {
        super.onLivingUpdate();
        
        this.getEntityAttribute(SharedMonsterAttributes.ATTACK_SPEED).setBaseValue(this.getWitherHealth() <= this.getMaxWitherHealth() * 0.2D ? (this.isSuperBoss() && !(this instanceof EntityWitherBedrock) ? 2D : 10D) : (this.isArmored() ? (this.isSuperBoss() && !(this instanceof EntityWitherBedrock) ? 10D : 20D) : (this.isSuperBoss() && !(this instanceof EntityWitherBedrock) ? 20D : 40D)));

		if (getMaxWitherHealth() != this.getMobHealth() && this.getWitherHealth() > 0)
		{
        	this.getEntityAttribute(CURRENT_HEALTH_WITHER).setBaseValue(this.getMobHealth());
        	this.getEntityAttribute(MAX_HEALTH_WITHER).setBaseValue(this.getMobHealth());
		}

        if (this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getBaseValue() != this.getMobAttack())
        	this.getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(this.getMobAttack());
        
    	this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(32D * this.getWitherScale());
        
    	if (this.posY < -65 - height && this.isSuperBoss())
 	          this.jump();
    	
    	if (this.posY > 240 - height && this.isSuperBoss())
	          this.posY = 200;
    	
    	if (++this.switchAI >= (isRaidBoss() ? 100 : 2000) || this.isArmored())
    	{
    		this.switchAI = 0;
    		if (this.isArmored())
    			shouldUseDynamicAI = 1;
    		else
    		{
    			if (shouldUseDynamicAI >= 1)
        			shouldUseDynamicAI = 0;
    			else
    				shouldUseDynamicAI = 1;
    		}
    	}

    	if (!this.isEntityAlive())
    	{
    		this.setSitting(false);
    		this.setRamTime(0);
    		this.setAttackTarget(null);
            for (int i = 0; i < 3; ++i)
            {
            	this.updateWatchedTargetId(i, 0);
            }
            this.getNavigator().clearPath();
    	}
    	
    	this.setSize(this.getBaseWidth() * this.getWitherScale(), this.getBaseHeight() * this.getWitherScale());
        
    	if (this.isEntityAlive())
    		this.onWitherMoveUpdate();
    	else if (motionY > 0)
    		motionY = -motionY;

        for (int i = 0; i < 2; ++i)
        {
            this.yRotOHeads[i] = this.yRotationHeads[i];
            this.xRotOHeads[i] = this.xRotationHeads[i];
        }

        for (int j = 0; j < getHeadCount() - 1; ++j)
        {
            int k = this.getWatchedTargetId(j + 1);
            Entity entity1 = null;

            if (k > 0)
            {
                entity1 = this.world.getEntityByID(k);
            }

            if (entity1 != null)
            {
                double d11 = this.getHeadX(j + 1);
                double d12 = this.getHeadY(j + 1);
                double d13 = this.getHeadZ(j + 1);
                double d6 = entity1.posX - d11;
                double d7 = entity1.posY + (double)entity1.getEyeHeight() - d12;
                double d8 = entity1.posZ - d13;
                double d9 = (double)MathHelper.sqrt(d6 * d6 + d8 * d8);
                float f = (float)(MathHelper.atan2(d8, d6) * (180D / Math.PI)) - 90.0F;
                float f1 = (float)(-(MathHelper.atan2(d7, d9) * (180D / Math.PI)));
                this.xRotationHeads[j] = this.rotlerp(this.xRotationHeads[j], f1, 40.0F);
                this.yRotationHeads[j] = this.rotlerp(this.yRotationHeads[j], f, 10.0F);
            }
            else
            {
                this.xRotationHeads[j] = this.rotlerp(this.xRotationHeads[j], this.deathTicks > 0 ? 50F - (deathTicks / 2) : 0, 10.0F);
                this.yRotationHeads[j] = this.rotlerp(this.yRotationHeads[j], this.renderYawOffset, 5.0F);
            }
        }
        
        if (this.posY > 0 - height && this.isEntityAlive())
        this.onWitherParticaleUpdate();
        if (this.isEntityAlive())
        if (this.getInvulTime() > 0)
        {
            if (this.ticksExisted % 5 == 0)
            {
                this.heal(this.getMaxWitherHealth() / 66);
            }
        }
        else
        {

            this.onHealUpdate();
        }
        
        if (this.isEntityInsideOpaqueBlock() && this.isSuperBoss())
        	this.blockBreakCounter = 1;
    }

    protected void updateAITasks()
    {
        if (this.getInvulTime() <= 0)
        {
            super.updateAITasks();

            this.onWitherTargetUpdate();

            if (this.getAttackTarget() != null && !this.isOnSameTeam(this.getAttackTarget()))
            {
                this.updateWatchedTargetId(0, this.getAttackTarget().getEntityId());
            }
            else
            {
                this.updateWatchedTargetId(0, 0);
            }

            this.breakBlocks(-((int)width + 1), (int)width + 1, 0, (int)height, -((int)width + 1), (int)width + 1);
        }
    }

    public final void breakBlocks(int x1, int x2, int y1, int y2, int z1, int z2)
    {
        if (this.blockBreakCounter > 0)
        {
            --this.blockBreakCounter;

            if (this.blockBreakCounter == 0 && (net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.world, this) || this.isSuperBoss()))
            {
                int i1 = MathHelper.floor(this.posY);
                int l1 = MathHelper.floor(this.posX);
                int i2 = MathHelper.floor(this.posZ);
                boolean flag = false;

                for (int k2 = x1; k2 <= x2; ++k2)
                {
                    for (int l2 = z1; l2 <= z2; ++l2)
                    {
                        for (int j = y1; j <= y2; ++j)
                        {
                            int i3 = l1 + k2;
                            int k = i1 + j;
                            int l = i2 + l2;
                            BlockPos blockpos = new BlockPos(i3, k, l);
                            IBlockState iblockstate = this.world.getBlockState(blockpos);
                            Block block = iblockstate.getBlock();

                            if (!block.isAir(iblockstate, this.world, blockpos) && (!MoWithers.isAnUnbreakable(block) || this.isSuperBoss() && blockpos.getY() > 0))
                            {
                                if (this instanceof EntityWitherVoid)
                                	EntityWitherVoid.consumeBlock((EntityWitherVoid) this, blockpos, world);
                                else
                                {
                                	flag = true;
                                	this.world.destroyBlock(blockpos, this.canDestroyBlock(blockpos));
                                }
                            }
                        }
                    }
                }

                if (flag)
                {
                    this.world.playEvent((EntityPlayer)null, 1022, new BlockPos(this), 0);
                }
            }
        }
    }

    /**
     * Get the position in the world. <b>{@code null} is not allowed!</b> If you are not an entity in the world, return
     * the coordinates 0, 0, 0
     */
    public BlockPos getPosition()
    {
        return new BlockPos(this);
    }
    
	public boolean canDestroyBlock(BlockPos blockIn)
    {
        return !MoWithers.isAnUnbreakable(world.getBlockState(blockIn).getBlock());
    }
    
    public boolean isImmuneToExplosions()
    {
        return this.isSuperBoss() || this.isRaidBoss();
    }

    /**
     * Initializes this Wither's explosion sequence and makes it invulnerable. Called immediately after spawning.
     */
    public void ignite()
    {
        this.setInvulTime(220);
        this.setHealth(this.getMaxHealth() / 3.0F);
    }

    /**
     * Sets the Entity inside a web block.
     */
    public void setInWeb()
    {
    }

    /**
     * Add the given player to the list of players tracking this entity. For instance, a player may track a boss in
     * order to view its associated boss bar.
     */
    public void addTrackingPlayer(EntityPlayerMP player)
    {
        super.addTrackingPlayer(player);
        if (!this.isTamed())
        this.bossInfo.addPlayer(player);
    }

    /**
     * Removes the given player from the list of players tracking this entity. See {@link Entity#addTrackingPlayer} for
     * more information on tracking.
     */
    public void removeTrackingPlayer(EntityPlayerMP player)
    {
        super.removeTrackingPlayer(player);
        this.bossInfo.removePlayer(player);
    }

    protected double getHeadX(int p_82214_1_)
    {
        if (p_82214_1_ <= 0)
        {
            return this.posX;
        }
        else
        {
            float f = (this.renderYawOffset + (float)(180 * (p_82214_1_ - 1))) * 0.017453292F;
            float f1 = MathHelper.cos(f);
            return this.posX + (double)f1 * (0.65D * this.getWitherScale());
        }
    }

    protected double getHeadY(int p_82208_1_)
    {
        return p_82208_1_ <= 0 ? this.posY + this.getEyeHeight() : this.posY + (this.getEyeHeight() * 0.8D);
    }

    protected double getHeadZ(int p_82213_1_)
    {
        if (p_82213_1_ <= 0)
        {
            return this.posZ;
        }
        else
        {
            float f = (this.renderYawOffset + (float)(180 * (p_82213_1_ - 1))) * 0.017453292F;
            float f1 = MathHelper.sin(f);
            return this.posZ + (double)f1 * (0.65D * this.getWitherScale());
        }
    }

    private float rotlerp(float p_82204_1_, float p_82204_2_, float p_82204_3_)
    {
        float f = MathHelper.wrapDegrees(p_82204_2_ - p_82204_1_);

        if (f > p_82204_3_)
        {
            f = p_82204_3_;
        }

        if (f < -p_82204_3_)
        {
            f = -p_82204_3_;
        }

        return p_82204_1_ + f;
    }

    private void launchWitherSkullToEntity(int p_82216_1_, EntityLivingBase p_82216_2_)
    {
        this.launchWitherSkullToCoords(p_82216_1_, p_82216_2_.posX + p_82216_2_.motionX, p_82216_2_.posY + (rand.nextDouble() * ((double)p_82216_2_.getEyeHeight() * 0.5D)), p_82216_2_.posZ + p_82216_2_.motionZ, p_82216_1_ == 0 && (this.rand.nextFloat() < 0.001F || !this.canEntityBeSeen(p_82216_2_)));
    }

    /**
     * Launches a Wither skull toward (par2, par4, par6)
     */
    protected void launchWitherSkullToCoords(int p_82209_1_, double x, double y, double z, boolean invulnerable)
    {
        double d0 = this.getHeadX(p_82209_1_);
        double d1 = this.getHeadY(p_82209_1_);
        double d2 = this.getHeadZ(p_82209_1_);
        double d3 = x - d0;
        double d4 = y - d1;
        double d5 = z - d2;
        EntityWitherSkullShared entitywitherskull = new EntityWitherSkullShared(this.world, this, d3, d4, d5);
        this.setSkullStats(entitywitherskull, (float)getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getBaseValue(), invulnerable);
    	if (isRaidBoss())
    		entitywitherskull.setRadius(entitywitherskull.getRadius() * 6F);
    	
        if (world.getDifficulty() == EnumDifficulty.PEACEFUL)
    		entitywitherskull.setRadius(entitywitherskull.getRadius() * 0.25F);
    	
        if (world.getDifficulty() == EnumDifficulty.EASY)
    		entitywitherskull.setRadius(entitywitherskull.getRadius() * 0.75F);
        
        if (world.getDifficulty() == EnumDifficulty.HARD)
    		entitywitherskull.setRadius(entitywitherskull.getRadius() * 1.5F);
       
        if (entitywitherskull.isInvulnerable())
    		entitywitherskull.setRadius(entitywitherskull.getRadius() * 3F);
        entitywitherskull.posY = d1;
        entitywitherskull.posX = d0;
        entitywitherskull.posZ = d2;
        this.world.spawnEntity(entitywitherskull);
        if (entitywitherskull.getType() != 17)
    	world.playSound(null, d0, d1, d2, SoundEvents.ENTITY_WITHER_SHOOT, getSoundCategory(), this.getSoundVolume(), 1F);
    }
    
    protected void setSkullStats(EntityWitherSkullShared skull, float damage, boolean invul)
    {
        skull.setInvulnerable(invul);
        skull.setDamage(damage);
        skull.setRadius(1F);
        skull.setSkullSize(this.getWitherScale() * 0.25F);
        skull.setSkullTexture("wither");
    }
    
    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    /**
     * Attack the specified entity using a ranged attack.
     */
    public void attackEntityWithRangedAttack(EntityLivingBase target, float distanceFactor)
    {
        this.launchWitherSkullToEntity(0, target);
    }
    
    public void onKillCommand()
    {
        if (!this.isSuperBoss())
        	this.isDead = true;
    }
    
    public void broadcastSound(SoundEvent sound, float pitch)
    {
    	if (!world.playerEntities.isEmpty())
    	{
            for (EntityPlayer entity : world.playerEntities)
            {
        		world.playSound(null, entity.getPosition(), sound, getSoundCategory(), 5F, pitch);
            }
    	}
    }

    /**
     * Called when the entity is attacked.
     */
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
    	if (amount <= 0)
    	{
    		amount = 0;
    		return false;
    	}
    	
    	if (source.isExplosion() && this.getTotalArmorValue() <= 0)
    		amount *= 5;
    	
        if (!net.minecraftforge.common.ForgeHooks.onLivingAttack(this, source, amount)) return false;
        if (this.isEntityInvulnerable(source))
        {
            return false;
        }
        else if (this.world.isRemote)
        {
            return false;
        }
        else if (source.getTrueSource() == null && this.isSuperBoss())
        {
            return false;
        }
        else if (this.getWitherHealth() <= 0.0F)
        {
            return false;
        }
        else
        {
            if (this.getInvulTime() > 0 && source != DamageSource.OUT_OF_WORLD)
            {
                return false;
            }
            else if (this.isImmuneToFire() && (source == DamageSource.LIGHTNING_BOLT || source.isFireDamage()))
            {
                return false;
            }
            else
            {
                
                Entity entity = source.getImmediateSource();
                
                if (this.isArmored() || this.getRamTime() > 60 || this.isRaidBoss())
                {
                    if (entity instanceof EntityArrow)
                    {
                        return false;
                    }
                    if (!(entity instanceof EntityWitherSkullShared))
                    amount *= 0.5F;
                }
                
                if (entity != null && entity instanceof EntityWitherSkullShared)
                {
                	EntityWitherSkullShared skull = (EntityWitherSkullShared)entity;
                	
                	if (skull.shootingEntity != null && !(skull.shootingEntity instanceof EntityPlayer) && this.hitType(source, skull.shootingEntity))
                		return false;
                }

                Entity entity1 = source.getTrueSource();

                if (entity1 != null && this.isOnSameTeam(entity1))
                {
                    return false;
                }
                else
                {
                    if (entity1 != null && entity1 instanceof EntityLivingBase && !((EntityLivingBase)entity1).getHeldItemMainhand().isEmpty())
                    {
                        if (this.getWitherType() == EnumWitherType.BLOCK_ROCK && ((EntityLivingBase)entity1).getHeldItemMainhand().getItem() instanceof ItemPickaxe)
                        {
                        	amount *= 7.5F;
                        }
                        if (this.getWitherType() == EnumWitherType.BLOCK_WOOD && ((EntityLivingBase)entity1).getHeldItemMainhand().getItem() instanceof ItemAxe)
                        {
                        	amount *= 3F;
                        }
                        if (this.getWitherType() == EnumWitherType.BLOCK_SOFT && ((EntityLivingBase)entity1).getHeldItemMainhand().getItem() instanceof ItemSpade)
                        {
                        	amount *= 5F;
                        }
                        if (this.getWitherType() == EnumWitherType.MOB && ((EntityLivingBase)entity1).getHeldItemMainhand().getItem() instanceof ItemSword)
                        {
                        	amount *= 1.5F;
                        }
                    }
                	
                	if (amount >= this.getMaxWitherHealth() * 0.1D && (this.isSuperBoss() || this.isRaidBoss()))
                		amount = (float) (this.getMaxWitherHealth() * 0.1D);
                	
                    if (getAbsorptionAmount() > 0.0F && !this.isEntityInvulnerable(source))
                    {
                      amount /= 2.0F;
                      this.playSound(SoundEvents.BLOCK_ANVIL_LAND, 3.0F, getSoundPitch() - this.rand.nextFloat() * 0.7F);
                      if (!source.isMagicDamage() && source.getTrueSource() instanceof EntityLivingBase)
                      {
                        EntityLivingBase entitylivingbase = (EntityLivingBase)source.getTrueSource();
                        if (!source.isExplosion())
                          entitylivingbase.attackEntityFrom(DamageSource.causeThornsDamage(this), 5.0F);
                        
                      }
                    }
                	
                    if (this.blockBreakCounter <= 0)
                    {
                        this.blockBreakCounter = 20;
                    }

                    for (int i = 0; i < this.idleHeadUpdates.length; ++i)
                    {
                        this.idleHeadUpdates[i] += 3;
                    }
                    
                    if (rand.nextInt(3) == 0 && entity1 != null)
                    	this.setAttackTarget(null);

                    this.idleTime = 0;

                    if (this.getWitherHealth() <= 0.0F)
                    {
                        return false;
                    }
                    else if (source.isFireDamage() && this.isPotionActive(MobEffects.FIRE_RESISTANCE))
                    {
                        return false;
                    }
                    else if (hurtResistantTime >= maxHurtResistantTime / 2 && source != DamageSource.OUT_OF_WORLD && source != DamageSource.STARVE && !source.isExplosion() && !this.isSuperBoss())
                    {
                        return false;
                    }
                    else
                    {
                        float f = amount;

                        boolean flag = false;

                        this.limbSwingAmount = 1.5F;
                        boolean flag1 = true;

                        this.lastDamage = amount;
                        this.hurtResistantTime = this.maxHurtResistantTime;
                        this.damageEntity(source, amount);
                        this.maxHurtTime = 10;
                        this.hurtTime = this.maxHurtTime;

                        this.attackedAtYaw = 0.0F;
                        Entity entity11 = source.getTrueSource();

                        if (entity11 != null)
                        {
                            if (entity11 instanceof EntityLivingBase)
                            {
                                this.setRevengeTarget((EntityLivingBase)entity11);
                            }

                            this.recentlyHit = 100;
                            if (entity11 instanceof EntityPlayer)
                            {
                                this.attackingPlayer = (EntityPlayer)entity11;
                            }
                        }

                        if (flag1)
                        {
                            if (flag)
                            {
                                this.world.setEntityState(this, (byte)29);
                            }
                            else if (source instanceof EntityDamageSource && ((EntityDamageSource)source).getIsThornsDamage())
                            {
                                this.world.setEntityState(this, (byte)33);
                            }
                            else
                            {
                                this.world.setEntityState(this, (byte)2);
                            }
                        }

                        if (this.getWitherHealth() <= 0.0F)
                        {
                            SoundEvent soundevent = this.getDeathSound();

                            if (flag1 && soundevent != null)
                            {
                                this.playSound(soundevent, this.getSoundVolume(), this.getSoundPitch());
                            }

                            this.onDeath(source);
                        }
                        else if (flag1)
                        {
                            this.playHurtSound(source);
                        }

                        boolean flag2 = !flag || amount > 0.0F;

                        if (entity11 instanceof EntityPlayerMP)
                        {
                            CriteriaTriggers.PLAYER_HURT_ENTITY.trigger((EntityPlayerMP)entity11, this, source, f, amount, flag);
                        }

                        return flag2;
                    }
                }
            }
        }
    }

    protected boolean hitType(DamageSource source, Entity entity)
    {
    	return entity == this || entity.getClass() == this.getClass() || (this.isEntityUndead() && !this.isRaidBoss() && !this.isSuperBoss() && MoWithers.isWitherMob((EntityLivingBase)entity));
    }
    
    /**
     * drops the loot of this entity upon death
     */
    protected void dropLoot(boolean wasRecentlyHit, int lootingModifier, DamageSource source) 
    {
    	if (this.deathTime > 1 || this.deathTicks > 1)
    	this.dropFewItems(wasRecentlyHit, lootingModifier);
    }
    
    protected int minDropNum(int lootingModifier)
    {
    	return 16 + lootingModifier;
    }
    
    protected int maxDropNum(int lootingModifier)
    {
    	return 32 + lootingModifier;
    }
    
    @Nullable
    protected Item getDropItem()
    {
        return Items.COAL;
    }

	/**
     * Drop 0-2 items of this living's type
     */
    protected void dropFewItems(boolean wasRecentlyHit, int lootingModifier)
    {
        this.dropItem(Items.NETHER_STAR, this.isRaidBoss() ? 64 : 1);
    	
        for (int k = 0; k < Maths.random(this.minDropNum(lootingModifier) * (this.isRaidBoss() ? 32 : 1), this.maxDropNum(lootingModifier) * (this.isRaidBoss() ? 64 : 1)); ++k)
        {
            this.dropItem(getDropItem(), 1);
        }

        for (int k = 0; k < Maths.random(12 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 32 : 1), 20 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 64 : 1)); ++k)
        {
            this.dropItem(MItems.WITHER_BONE, 1);
        }

        for (int k = 0; k < Maths.random(8 + lootingModifier * this.getWitherScale(), 16 + lootingModifier * this.getWitherScale()); ++k)
        {
            this.dropItem(this.isRaidBoss() ? MItems.ENTROPIC_MATTER_UNSTABLE : MItems.ATROPHIC_SHARD, 1);
        }
        
        if (isRaidBoss())
        {
            for (int k = 0; k < Maths.random(12 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 32 : 1), 20 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 64 : 1)); ++k)
            {
                this.dropItem(Item.getItemFromBlock(Blocks.DIAMOND_BLOCK), 1);
            }
            
            for (int k = 0; k < Maths.random(12 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 32 : 1), 20 + lootingModifier * this.getWitherScale() * (this.isRaidBoss() ? 64 : 1)); ++k)
            {
                this.dropItem(Item.getItemFromBlock(Blocks.EMERALD_BLOCK), 1);
            }
        }
        
        this.dropEquipment(wasRecentlyHit, lootingModifier);
    }
    
    @Nullable
    public EntityItem dropItem(Item itemIn, int size)
    {
        return this.dropItemWithOffset(itemIn, size, this.getEyeHeight());
    }
    
    /**
     * Drops an item at the position of the entity.
     */
    @Nullable
    public EntityItem entityDropItem(ItemStack stack, float offsetY)
    {
        if (stack.isEmpty())
        {
            return null;
        }
        else
        {
            EntityItem entityitem = new EntityItem(this.world, this.posX, this.posY + (double)offsetY, this.posZ, stack);
            entityitem.setDefaultPickupDelay();
            entityitem.setNoDespawn();
            entityitem.setEntityInvulnerable(true);
            entityitem.motionY = 0.5D;
            if (captureDrops)
                this.capturedDrops.add(entityitem);
            else
                this.world.spawnEntity(entityitem);
            return entityitem;
        }
    }
    
    @Nullable
    public void dropXP(double x, double y, double z, int i)
    {
        i = net.minecraftforge.event.ForgeEventFactory.getExperienceDrop(this, this.attackingPlayer, i);
        while (i > 0)
        {
            int j = EntityXPOrb.getXPSplit(i);
            i -= j;
            EntityXPOrb orb = new EntityXPOrb(this.world, x, y, z, j);
            orb.setEntityInvulnerable(true);
            this.world.spawnEntity(orb);
        }
        this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0F, (1.0F + (this.world.rand.nextFloat() - this.world.rand.nextFloat()) * 0.2F) * 0.7F);
    }

    /**
     * handles entity death timer, experience orb and particle creation
     */
    protected void onDeathUpdate()
    {
    	if (this.getWitherHealth() <= 0)
    	{
    		++deathTime;
            this.setSneaking(true);

            if (!this.noClip)
            this.motionY -= 0.2D;
            
            if (this.deathTime == 1)
            {
            	this.ticksExisted = 1;
            	this.playSound(getDeathSound(), this.getSoundVolume(), this.getSoundPitch());
            }
            
            if (this.deathTime == 30)
            {
            	this.playSound(MSounds.ENTITY_WITHER_FALL, this.getSoundVolume(), 1F);
            }
            
            if (!this.world.isRemote && this.deathTime == 50 && this.isTamed() && this.getOwner() != null)
            {
    			this.getOwner().sendMessage(new TextComponentTranslation("Your " + this.getName() + " has fainted." , new Object[0]));
            }
            
            if (this.deathTime >= 55 && this.isTamed())
            {
            	this.deathTime = 55;
            }
            
            if (this.deathTime == 60)
            {
                if (!this.world.isRemote && this.canDropLoot() && this.world.getGameRules().getBoolean("doMobLoot"))
                {
                	if (this.world.getDifficulty() == EnumDifficulty.NORMAL)
                		experienceValue *= 1.5;
                	if (this.world.getDifficulty() == EnumDifficulty.HARD)
                		experienceValue *= 3;
                	if (this.isRaidBoss())
                		experienceValue *= 9000;
                	this.dropXP(posX, posY + this.getEyeHeight(), posZ, this.experienceValue);
                    this.dropLoot(true, 0, getLastDamageSource());
                    if (this instanceof EntityWitherLightning)
                        this.world.addWeatherEffect(new EntityLightningBolt(this.world, this.posX - 0.5D, this.posY, this.posZ - 0.5D, false));
                }

                this.setDead();

                for (int k = 0; k < 20; ++k)
                {
                    double d2 = this.rand.nextGaussian() * 0.02D;
                    double d0 = this.rand.nextGaussian() * 0.02D;
                    double d1 = this.rand.nextGaussian() * 0.02D;
                    this.world.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d2, d0, d1);
                    this.world.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, this.posX + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, this.posY + (double)(this.rand.nextFloat() * this.height), this.posZ + (double)(this.rand.nextFloat() * this.width * 2.0F) - (double)this.width, d2, d0, d1);
                }
            }
    	}
    	else
    		--deathTime;
    }
    
    /**
     * Makes the entity despawn if requirements are reached
     */
    protected void despawnEntity()
    {
        this.idleTime = 0;
        if (!this.isNoDespawnRequired())
        	this.enablePersistence();
    }

    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender()
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness()
    {
        return 1.0F;
    }
    
    public void fall(float distance, float damageMultiplier)
    {
    }

    /**
     * adds a PotionEffect to the entity
     */
    public void addPotionEffect(PotionEffect potioneffectIn)
    {
    }

    @SideOnly(Side.CLIENT)
    public float getHeadYRotation(int p_82207_1_)
    {
        return this.yRotationHeads[p_82207_1_];
    }

    @SideOnly(Side.CLIENT)
    public float getHeadXRotation(int p_82210_1_)
    {
        return this.xRotationHeads[p_82210_1_];
    }

    public int getInvulTime()
    {
        return ((Integer)this.dataManager.get(INVULNERABILITY_TIME)).intValue();
    }

    public void setInvulTime(int time)
    {
        this.dataManager.set(INVULNERABILITY_TIME, Integer.valueOf(time));
    }

    public int getRamTime()
    {
        return ((Integer)this.dataManager.get(RAM_TIME)).intValue();
    }

    public void setRamTime(int time)
    {
        this.dataManager.set(RAM_TIME, Integer.valueOf(time));
    }

    public int getHeadCount()
    {
        return 3;
    }

    /**
     * Returns the target entity ID if present, or -1 if not @param par1 The target offset, should be from 0-2
     */
    public int getWatchedTargetId(int head)
    {
        return ((Integer)this.dataManager.get(HEAD_TARGETS[head])).intValue();
    }

    /**
     * Updates the target entity ID
     */
    public void updateWatchedTargetId(int targetOffset, int newId)
    {
        this.dataManager.set(HEAD_TARGETS[targetOffset], Integer.valueOf(newId));
    }

    /**
     * Returns whether the wither is armored with its boss armor or not by checking whether its health is below half of
     * its maximum.
     */
    public boolean isArmored()
    {
        return this.getWitherHealth() <= this.getMaxWitherHealth() * 0.5D;
    }    
    
    /**
     * Checks whether target entity is alive.
     */
    public boolean isEntityAlive()
    {
        return !this.isDead && this.getWitherHealth() > 0.0F;
    }

    /**
     * Get this Entity's EnumCreatureAttribute
     */
    public EnumCreatureAttribute getCreatureAttribute()
    {
        return EnumCreatureAttribute.UNDEAD;
    }

    /**
     * Returns true if this entity is undead.
     */
    public boolean isEntityUndead()
    {
        return true;
    }

    protected boolean canBeRidden(Entity entityIn)
    {
        return false;
    }

    /**
     * Returns false if this Entity is a boss, true otherwise.
     */
    public boolean isNonBoss()
    {
        return false;
    }

    /**
     * Returns true if this Entity is a superboss, false otherwise.
     */
    public boolean isSuperBoss()
    {
        return false;
    }

    public void setSwingingArms(boolean swingingArms)
    {
    }
    
    public boolean processInteract(EntityPlayer player, EnumHand hand)
    {
        ItemStack itemstack = player.getHeldItem(hand);

        if (this.isTamed())
        {
            if (!itemstack.isEmpty())
            {
                if (itemstack.getItem() instanceof ItemFood)
                {
                    ItemFood itemfood = (ItemFood)itemstack.getItem();

                    if (itemfood.isWolfsFavoriteMeat() && this.getWitherHealth() < this.getMaxWitherHealth())
                    {
                        if (!player.capabilities.isCreativeMode)
                        {
                            itemstack.shrink(1);
                        }

                        this.world.playEvent((EntityPlayer)null, 1022, new BlockPos(this), 0);
                        if (this.isTamed() && this.getWitherHealth() <= 0)
                        {
                        	this.setWitherHealth(this.getWitherHealth() + (double)itemfood.getHealAmount(itemstack));
                        	this.playSound(SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, 1F, 1F);
                        	this.hurtResistantTime = 200;
                        }
                        else
                        	this.heal((double)itemfood.getHealAmount(itemstack));
                        return true;
                    }
                }
            }
            else
            {
            	if (this.isSitting())
            		this.setSitting(false);
            	else
            		this.setSitting(true);
                return true;
            }
        }

        return super.processInteract(player, hand);
    }
    
    public EnumWitherType getWitherType()
    {
        return EnumWitherType.DEFAULT;
    }

    class AIDoNothing extends EntityAIBase
    {
        public AIDoNothing()
        {
            this.setMutexBits(7);
        }

        /**
         * Returns whether the EntityAIBase should begin execution.
         */
        public boolean shouldExecute()
        {
            return EntityBaseWither.this.getInvulTime() > 0 || EntityBaseWither.this.getRamTime() > 0 || EntityBaseWither.this.getWitherHealth() <= 0;
        }
    }

	public EnumLevel getTier() 
	{
		return EnumLevel.BISHOP;
	}

	public EnumGender getGender() 
	{
		return EnumGender.NONE;
	}

	public void setVariant(int type) {}

	public int getVariant() 
	{
		return 0;
	}

	public double getMobHealth() 
	{
		EnumDifficulty diff = world.getDifficulty();
		
		double hp = 300D;
		
		if (diff == EnumDifficulty.NORMAL)
			hp *= 1.5D;
		
		if (diff == EnumDifficulty.HARD)
			hp *= 2D;
		
		if (this.isRaidBoss())
			hp *= 5000D;
		
		return hp;
	}

	public double getMobAttack() 
	{
		return this.isRaidBoss() ? 800D : 8D;
	}

	public double getMobSpeed() 
	{
		return 0.6D;
	}
}