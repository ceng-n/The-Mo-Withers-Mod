package net.endermanofdoom.mowithers.entity.wither;

import net.endermanofdoom.mowithers.MoWithers;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.DamageSource;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.World;

public class EntityWitherNormal extends EntityHostileWither
{
	public EntityWitherNormal(World worldIn) 
	{
		super(worldIn);
	}
	
	protected void initEntityAI()
    {
		WITHERTARGETS = MoWithers.NON_WITHER_OR_NETHER_MOB;
        super.initEntityAI();
        this.targetTasks.addTask(2, new EntityAIWitherTargeting<EntityLivingBase>(this, EntityLivingBase.class, WITHERTARGETS));
    }
    
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        if (source == DamageSource.WITHER)
        {
          this.heal((double)amount);
          return false;
        }
        else
        {
        	return super.attackEntityFrom(source, amount);
        }
    }
    
    public TextFormatting getNameColor()
    {
    	return TextFormatting.DARK_GRAY;
    }
    
    /**
     * This method gets called when the entity kills another one.
     */
    public void onKillEntity(EntityLivingBase entityLivingIn)
    {
        super.onKillEntity(entityLivingIn);
        
        MoWithers.onKillEntity(this, entityLivingIn);
    }
    
	public int[] getBarColor() 
	{
		return new int[] {122, 122, 122, 0, 0, 0};
	}
}
