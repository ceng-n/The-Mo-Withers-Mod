package net.endermanofdoom.mowithers.entity.monster;

import java.util.Random;
import javax.annotation.Nullable;
import net.endermanofdoom.mowithers.MoWithers;
import net.endermanofdoom.mowithers.entity.wither.EntityAIWitherTargeting;
import net.endermanofdoom.mowithers.entity.wither.EntityWitherSkullShared;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureAttribute;
import net.minecraft.entity.IRangedAttackMob;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityMoveHelper;
import net.minecraft.entity.monster.IMob;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.minecraft.world.storage.loot.LootTableList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntityEvaporation extends EntityCreature implements IMob, IRangedAttackMob
{
    private static final DataParameter<Boolean> ATTACKING = EntityDataManager.<Boolean>createKey(EntityEvaporation.class, DataSerializers.BOOLEAN);
    /** The explosion radius of spawned fireballs. */
    private int explosionStrength = 2;
    
    public EntityEvaporation(World worldIn)
    {
        super(worldIn);
        this.setSize(4.8F, 4.8F);
        this.isImmuneToFire = true;
        this.experienceValue = 40;
        this.moveHelper = new EntityEvaporation.GhastMoveHelper(this);
    }

    protected void initEntityAI()
    {
        this.tasks.addTask(5, new EntityEvaporation.AIRandomFly(this));
        this.tasks.addTask(7, new EntityEvaporation.AILookAround(this));
        this.tasks.addTask(7, new EntityEvaporation.AIFireballAttack(this));
        this.targetTasks.addTask(1, new EntityAIHurtByTarget(this, true, new Class[0]));
        this.targetTasks.addTask(2, new EntityAIWitherTargeting<EntityLivingBase>(this, EntityLivingBase.class, MoWithers.NON_WITHER_OR_NETHER_MOB));
    }
    
    /**
     * This method gets called when the entity kills another one.
     */
    public void onKillEntity(EntityLivingBase entityLivingIn)
    {
        super.onKillEntity(entityLivingIn);
        
        MoWithers.onKillEntity(this, entityLivingIn);
    }

    /**
     * Get this Entity's EnumCreatureAttribute
     */
    public EnumCreatureAttribute getCreatureAttribute()
    {
        return EnumCreatureAttribute.UNDEAD;
    }

    public boolean attackEntityAsMob(Entity entityIn)
    {
        if (!super.attackEntityAsMob(entityIn))
        {
            return false;
        }
        else
        {
            if (entityIn instanceof EntityLivingBase)
            {
                ((EntityLivingBase)entityIn).addPotionEffect(new PotionEffect(MobEffects.WITHER, 200, 1));
            }

            return true;
        }
    }

    @SideOnly(Side.CLIENT)
    public boolean isAttacking()
    {
        return ((Boolean)this.dataManager.get(ATTACKING)).booleanValue();
    }

    public void setAttacking(boolean attacking)
    {
        this.dataManager.set(ATTACKING, Boolean.valueOf(attacking));
    }

    public int getFireballStrength()
    {
        return this.explosionStrength;
    }

    /**
     * Called to update the entity's position/logic.
     */
    public void onUpdate()
    {
        super.onUpdate();

        if (!this.world.isRemote && this.world.getDifficulty() == EnumDifficulty.PEACEFUL)
        {
            this.setDead();
        }
        
        if (this.isEntityAlive())
        {
            if (this.ticksExisted % 40 == 0)
            {
                this.heal(2.0F);
            }
            
            for (int i = 0; i < 6; ++i)
            	this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX + (this.rand.nextDouble() - 0.5D) * (double)width, this.posY + this.rand.nextDouble() * (double)this.height, this.posZ + (this.rand.nextDouble() - 0.5D) * (double)width, 0.0D, 0.0D, 0.0D);
        }
    }

    protected void entityInit()
    {
        super.entityInit();
        this.dataManager.register(ATTACKING, Boolean.valueOf(false));
    }

    protected void applyEntityAttributes()
    {
        super.applyEntityAttributes();
        this.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(100D);
        this.getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(10D);
        this.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(100.0D);
    }
    
    @Nullable
    protected ResourceLocation getLootTable()
    {
        return LootTableList.ENTITIES_WITHER_SKELETON;
    }

    protected SoundEvent getAmbientSound()
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_SKELETON_AMBIENT, this.getSoundVolume(), this.getSoundPitch() - 0.2F);
        return SoundEvents.ENTITY_GHAST_SCREAM;
    }

    protected SoundEvent getHurtSound(DamageSource damageSourceIn)
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_HURT, this.getSoundVolume(), this.getSoundPitch() - 0.2F);
        return SoundEvents.ENTITY_GHAST_HURT;
    }

    protected SoundEvent getDeathSound()
    {
    	this.playSound(SoundEvents.ENTITY_WITHER_DEATH, this.getSoundVolume(), this.getSoundPitch() - 0.2F);
        return SoundEvents.ENTITY_GHAST_DEATH;
    }
    
    /**
     * returns if this entity triggers Block.onEntityWalking on the blocks they walk on. used for spiders and wolves to
     * prevent them from trampling crops
     */
    protected boolean canTriggerWalking()
    {
        return false;
    }

    @SideOnly(Side.CLIENT)
    public int getBrightnessForRender()
    {
        return 15728880;
    }

    /**
     * Gets how bright this entity is.
     */
    public float getBrightness()
    {
        return 1.0F;
    }

    /**
     * Returns the volume for the sounds this mob makes.
     */
    protected float getSoundVolume()
    {
        return 10.0F;
    }

    /**
     * Checks if the entity's current position is a valid location to spawn this entity.
     */
    public boolean getCanSpawnHere()
    {
        return this.rand.nextInt(20) == 0 && super.getCanSpawnHere() && this.world.getDifficulty() != EnumDifficulty.PEACEFUL;
    }

    /**
     * Will return how many at most can spawn in a chunk at once.
     */
    public int getMaxSpawnedInChunk()
    {
        return 1;
    }

    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound compound)
    {
        super.writeEntityToNBT(compound);
        compound.setInteger("ExplosionPower", this.explosionStrength);
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    public void readEntityFromNBT(NBTTagCompound compound)
    {
        super.readEntityFromNBT(compound);

        if (compound.hasKey("ExplosionPower", 99))
        {
            this.explosionStrength = compound.getInteger("ExplosionPower");
        }
    }
    
    public void attackEntityWithRangedAttack(EntityLivingBase target, float distanceFactor)
    {
        Vec3d vec3d = this.getLook(1.0F);
        double d0 = (this.posX + vec3d.x * 2.5);
        double d1 = (this.posY + (double)(this.getEyeHeight() / 2F));
        double d2 = (this.posZ + vec3d.z * 2.5);
        double d3 = (target.posX + (rand.nextGaussian() * 2)) - d0;
        double d4 = (target.getEntityBoundingBox().minY + (double)(target.height / 2.0F)) - d1;
        double d5 = (target.posZ + (rand.nextGaussian() * 2)) - d2;
        EntityWitherSkullShared skull = new EntityWitherSkullShared(this.world, this, d3, d4, d5);
        skull.setDamage(8F);
        skull.setRadius(this.explosionStrength);
        skull.setBurn(true);
        skull.setDeflect(true);
        skull.posX = d0;
        skull.posY = d1;
        skull.posZ = d2;
        skull.noClip = true;
        skull.setSkullTexture("wither");
        world.spawnEntity(skull);
    }

	public void setSwingingArms(boolean swingingArms) {}
    
    public void fall(float distance, float damageMultiplier)
    {
    }

    protected void updateFallState(double y, boolean onGroundIn, IBlockState state, BlockPos pos)
    {
    }

    public void travel(float strafe, float vertical, float forward)
    {
        if (this.isInWater())
        {
            this.moveRelative(strafe, vertical, forward, 0.02F);
            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.800000011920929D;
            this.motionY *= 0.800000011920929D;
            this.motionZ *= 0.800000011920929D;
        }
        else if (this.isInLava())
        {
            this.moveRelative(strafe, vertical, forward, 0.02F);
            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            this.motionX *= 0.5D;
            this.motionY *= 0.5D;
            this.motionZ *= 0.5D;
        }
        else
        {
            float f = 0.91F;

            if (this.onGround)
            {
                BlockPos underPos = new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.getEntityBoundingBox().minY) - 1, MathHelper.floor(this.posZ));
                IBlockState underState = this.world.getBlockState(underPos);
                f = underState.getBlock().getSlipperiness(underState, this.world, underPos, this) * 0.91F;
            }

            float f1 = 0.16277136F / (f * f * f);
            this.moveRelative(strafe, vertical, forward, this.onGround ? 0.1F * f1 : 0.02F);
            f = 0.91F;

            if (this.onGround)
            {
                BlockPos underPos = new BlockPos(MathHelper.floor(this.posX), MathHelper.floor(this.getEntityBoundingBox().minY) - 1, MathHelper.floor(this.posZ));
                IBlockState underState = this.world.getBlockState(underPos);
                f = underState.getBlock().getSlipperiness(underState, this.world, underPos, this) * 0.91F;
            }

            this.move(MoverType.SELF, this.motionX, this.motionY, this.motionZ);
            this.motionX *= (double)f;
            this.motionY *= (double)f;
            this.motionZ *= (double)f;
        }

        this.prevLimbSwingAmount = this.limbSwingAmount;
        double d1 = this.posX - this.prevPosX;
        double d0 = this.posZ - this.prevPosZ;
        float f2 = MathHelper.sqrt(d1 * d1 + d0 * d0) * 4.0F;

        if (f2 > 1.0F)
        {
            f2 = 1.0F;
        }

        this.limbSwingAmount += (f2 - this.limbSwingAmount) * 0.4F;
        this.limbSwing += this.limbSwingAmount;
    }

    /**
     * Returns true if this entity should move as if it were on a ladder (either because it's actually on a ladder, or
     * for AI reasons)
     */
    public boolean isOnLadder()
    {
        return false;
    }

    public float getEyeHeight()
    {
        return 3.12F;
    }

    /**
     * Returns true if the entity is on fire. Used by render to add the fire effect on rendering.
     */
    public boolean isBurning()
    {
        return false;
    }

    /**
     * Returns whether this Entity is on the same team as the given Entity.
     */
    public boolean isOnSameTeam(Entity entityIn)
    {
        if (super.isOnSameTeam(entityIn))
        {
            return true;
        }
        else if (entityIn instanceof EntityLivingBase && MoWithers.isWitherMob((EntityLivingBase)entityIn))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        if (source == DamageSource.WITHER)
        {
          this.heal(amount);
          return false;
        }
        else
        {
        	if (source.getTrueSource() != null && source.getTrueSource() instanceof EntityLivingBase && MoWithers.isWitherMob((EntityLivingBase)source.getTrueSource()))
        		return false;
        	
        	return super.attackEntityFrom(source, amount);
        }
    }

    static class AIFireballAttack extends EntityAIBase
        {
            private final EntityEvaporation parentEntity;
            public int attackTimer;

            public AIFireballAttack(EntityEvaporation ghast)
            {
                this.parentEntity = ghast;
            }

            /**
             * Returns whether the EntityAIBase should begin execution.
             */
            public boolean shouldExecute()
            {
                return this.parentEntity.getAttackTarget() != null;
            }

            /**
             * Execute a one shot task or start executing a continuous task
             */
            public void startExecuting()
            {
                this.attackTimer = 0;
            }

            /**
             * Reset the task's internal state. Called when this task is interrupted by another one
             */
            public void resetTask()
            {
                this.parentEntity.setAttacking(false);
            }

            /**
             * Keep ticking a continuous task that has already been started
             */
            public void updateTask()
            {
                EntityLivingBase entitylivingbase = this.parentEntity.getAttackTarget();
                double d0 = parentEntity.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getBaseValue();

                if (entitylivingbase.getDistanceSq(this.parentEntity) < d0 * d0 && this.parentEntity.canEntityBeSeen(entitylivingbase))
                {
                    World world = this.parentEntity.world;
                    ++this.attackTimer;

                    if (this.attackTimer == 10)
                    {
                        world.playEvent((EntityPlayer)null, 1015, new BlockPos(this.parentEntity), 0);
                    }

                    if (this.attackTimer == 20)
                    {
                        for (int i = 0; i < 20; ++i)
                        {
                        	parentEntity.attackEntityWithRangedAttack(entitylivingbase, 0);
                        }
                        parentEntity.world.playEvent((EntityPlayer)null, 1024, new BlockPos(parentEntity), 0);
                        this.attackTimer = -40;
                    }
                }
                else if (this.attackTimer > 0)
                {
                    --this.attackTimer;
                }

                this.parentEntity.setAttacking(this.attackTimer > 10);
            }
        }

    static class AILookAround extends EntityAIBase
        {
            private final EntityEvaporation parentEntity;

            public AILookAround(EntityEvaporation ghast)
            {
                this.parentEntity = ghast;
                this.setMutexBits(2);
            }

            /**
             * Returns whether the EntityAIBase should begin execution.
             */
            public boolean shouldExecute()
            {
                return true;
            }

            /**
             * Keep ticking a continuous task that has already been started
             */
            public void updateTask()
            {
                if (this.parentEntity.getAttackTarget() == null)
                {
                    this.parentEntity.rotationYawHead = -((float)MathHelper.atan2(this.parentEntity.motionX, this.parentEntity.motionZ)) * (180F / (float)Math.PI);
                    this.parentEntity.renderYawOffset = this.parentEntity.rotationYaw = this.parentEntity.rotationYawHead;
                }
                else
                {
                    EntityLivingBase entitylivingbase = this.parentEntity.getAttackTarget();
                    double d0 = parentEntity.getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).getBaseValue();

                    if (entitylivingbase.getDistanceSq(this.parentEntity) < d0 * d0)
                    {
                        parentEntity.getLookHelper().setLookPositionWithEntity(entitylivingbase, 180, 0);
                        this.parentEntity.renderYawOffset = this.parentEntity.rotationYaw = this.parentEntity.rotationYawHead;
                    }
                }
            }
        }

    static class AIRandomFly extends EntityAIBase
        {
            private final EntityEvaporation parentEntity;

            public AIRandomFly(EntityEvaporation ghast)
            {
                this.parentEntity = ghast;
                this.setMutexBits(1);
            }

            /**
             * Returns whether the EntityAIBase should begin execution.
             */
            public boolean shouldExecute()
            {
                EntityMoveHelper entitymovehelper = this.parentEntity.getMoveHelper();

                if (!entitymovehelper.isUpdating())
                {
                    return true;
                }
                else
                {
                    double d0 = entitymovehelper.getX() - this.parentEntity.posX;
                    double d1 = entitymovehelper.getY() - this.parentEntity.posY;
                    double d2 = entitymovehelper.getZ() - this.parentEntity.posZ;
                    double d3 = d0 * d0 + d1 * d1 + d2 * d2;
                    return d3 < 1.0D || d3 > 4096.0D;
                }
            }

            /**
             * Returns whether an in-progress EntityAIBase should continue executing
             */
            public boolean shouldContinueExecuting()
            {
                return false;
            }

            /**
             * Execute a one shot task or start executing a continuous task
             */
            public void startExecuting()
            {
                Random random = this.parentEntity.getRNG();
                double d0 = this.parentEntity.posX + (double)((random.nextFloat() * 2.0F - 1.0F) * 24.0F);
                double d1 = this.parentEntity.posY + (double)((random.nextFloat() * 2.0F - 1.0F) * 24.0F);
                double d2 = this.parentEntity.posZ + (double)((random.nextFloat() * 2.0F - 1.0F) * 24.0F);
                this.parentEntity.getMoveHelper().setMoveTo(d0, d1, d2, 1.0D);
            }
        }

    static class GhastMoveHelper extends EntityMoveHelper
        {
            private final EntityEvaporation parentEntity;
            private int courseChangeCooldown;

            public GhastMoveHelper(EntityEvaporation ghast)
            {
                super(ghast);
                this.parentEntity = ghast;
            }

            public void onUpdateMoveHelper()
            {
                if (this.action == EntityMoveHelper.Action.MOVE_TO)
                {
                    double d0 = this.posX - this.parentEntity.posX;
                    double d1 = this.posY - this.parentEntity.posY;
                    double d2 = this.posZ - this.parentEntity.posZ;
                    double d3 = d0 * d0 + d1 * d1 + d2 * d2;

                    if (this.courseChangeCooldown-- <= 0)
                    {
                        this.courseChangeCooldown += this.parentEntity.getRNG().nextInt(5) + 2;
                        d3 = (double)MathHelper.sqrt(d3);

                        if (this.isNotColliding(this.posX, this.posY, this.posZ, d3))
                        {
                            this.parentEntity.motionX += d0 / d3 * 0.1D;
                            this.parentEntity.motionY += d1 / d3 * 0.1D;
                            this.parentEntity.motionZ += d2 / d3 * 0.1D;
                        }
                        else
                        {
                            this.action = EntityMoveHelper.Action.WAIT;
                        }
                    }
                }
            }

            /**
             * Checks if entity bounding box is not colliding with terrain
             */
            private boolean isNotColliding(double x, double y, double z, double p_179926_7_)
            {
                double d0 = (x - this.parentEntity.posX) / p_179926_7_;
                double d1 = (y - this.parentEntity.posY) / p_179926_7_;
                double d2 = (z - this.parentEntity.posZ) / p_179926_7_;
                AxisAlignedBB axisalignedbb = this.parentEntity.getEntityBoundingBox();

                for (int i = 1; (double)i < p_179926_7_; ++i)
                {
                    axisalignedbb = axisalignedbb.offset(d0, d1, d2);

                    if (!this.parentEntity.world.getCollisionBoxes(this.parentEntity, axisalignedbb).isEmpty())
                    {
                        return false;
                    }
                }

                return true;
            }
        }
}