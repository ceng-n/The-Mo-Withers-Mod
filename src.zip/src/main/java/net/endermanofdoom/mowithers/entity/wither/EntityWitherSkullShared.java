package net.endermanofdoom.mowithers.entity.wither;

import java.util.List;

import javax.annotation.Nullable;

import com.google.common.base.Optional;

import net.endermanofdoom.mac.util.math.Maths;
import net.endermanofdoom.mowithers.MoWithers;
import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAreaEffectCloud;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.entity.item.EntityItem;
import net.minecraft.entity.item.EntityTNTPrimed;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.projectile.EntityFireball;
import net.minecraft.init.Blocks;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.Explosion;
import net.minecraft.world.World;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class EntityWitherSkullShared extends EntityFireball
{
    private static final DataParameter<Boolean> INVULNERABLE = EntityDataManager.<Boolean>createKey(EntityWitherSkullShared.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> BURNING = EntityDataManager.<Boolean>createKey(EntityWitherSkullShared.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> DEFLECT = EntityDataManager.<Boolean>createKey(EntityWitherSkullShared.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> TYPE = EntityDataManager.<Integer>createKey(EntityWitherSkullShared.class, DataSerializers.VARINT);
    private static final DataParameter<String> TEXTURE = EntityDataManager.<String>createKey(EntityWitherSkullShared.class, DataSerializers.STRING);
    private static final DataParameter<Float> DAMAGE = EntityDataManager.<Float>createKey(EntityWitherSkullShared.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> RADIUS = EntityDataManager.<Float>createKey(EntityWitherSkullShared.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> SIZE = EntityDataManager.<Float>createKey(EntityWitherSkullShared.class, DataSerializers.FLOAT);
    private static final DataParameter<Optional<IBlockState>> PLACED_BLOCK = EntityDataManager.<Optional<IBlockState>>createKey(EntityWitherSkullShared.class, DataSerializers.OPTIONAL_BLOCK_STATE);

    public EntityWitherSkullShared(World worldIn)
    {
        super(worldIn);
        this.setSize(0.5F, 0.5F);
    }

    public EntityWitherSkullShared(World worldIn, EntityLivingBase shooter, double accelX, double accelY, double accelZ)
    {
        super(worldIn, shooter, accelX, accelY, accelZ);
        this.setSize(0.5F, 0.5F);
    }

    @SideOnly(Side.CLIENT)
    public EntityWitherSkullShared(World worldIn, double x, double y, double z, double accelX, double accelY, double accelZ)
    {
        super(worldIn, x, y, z, accelX, accelY, accelZ);
        this.setSize(0.5F, 0.5F);
    }

    /**
     * Returns true if the entity is on fire. Used by render to add the fire effect on rendering.
     */
    public boolean isBurning()
    {
        return this.canBurn();
    }

    /**
     * Explosion resistance of a block relative to this entity
     */
    public float getExplosionResistance(Explosion explosionIn, World worldIn, BlockPos pos, IBlockState blockStateIn)
    {
        float f = super.getExplosionResistance(explosionIn, worldIn, pos, blockStateIn);
        Block block = blockStateIn.getBlock();

        if (this.isInvulnerable() && !MoWithers.isAnUnbreakable(block) && block.canEntityDestroy(blockStateIn, worldIn, pos, this) && net.minecraftforge.event.ForgeEventFactory.onEntityDestroyBlock(this.shootingEntity, pos, blockStateIn))
        {
            f = Math.min(0.8F, f);
        }

        return f;
    }

    /**
     * Called when this EntityFireball hits a block or entity.
     */
    protected void onImpact(RayTraceResult result)
    {
        if (!this.world.isRemote)
        {
            if (result.entityHit != null && !result.entityHit.isRidingOrBeingRiddenBy(this) && result.entityHit instanceof EntityLivingBase)
            {
                if (this.shootingEntity != null && result.entityHit != shootingEntity && !shootingEntity.isOnSameTeam(result.entityHit))
                {
                	if (this.getType() == 3 && result.entityHit instanceof EntityWitherFire)
                	{
                		this.setDamage(this.getDamage() * 2);
                        this.world.playSound(this.posX + 0.5D, this.posY + this.rand.nextFloat() * height, this.posZ + 0.5D, SoundEvents.BLOCK_FIRE_EXTINGUISH, this.getSoundCategory(), 1.0F, this.rand.nextFloat() * 0.7F + 0.3F, false);
                	}
                	
                	if (this.getType() == 16 && ((EntityLivingBase) result.entityHit).isEntityUndead())
                	{
                		this.setDamage(this.getDamage() * 3);
                        this.world.playSound(this.posX + 0.5D, this.posY + this.rand.nextFloat() * height, this.posZ + 0.5D, SoundEvents.BLOCK_FIRE_EXTINGUISH, this.getSoundCategory(), 1.0F, this.rand.nextFloat() * 0.7F + 0.3F, false);
                	}
                	
                	boolean attack = true;
                	
                	if (this.getType() == 16 && !(result.entityHit instanceof IMob))
                		attack = false;
                	
                	if (attack)
                		result.entityHit.attackEntityFrom(this.getDamageType(shootingEntity, result.entityHit), this.getDamage());
                	
                    if (this.getType() == 16)
                    {
                    	if (result.entityHit instanceof IMob)
                    	{
                    		result.entityHit.setFire(5);
                    	}
                    	else
                    	{
                    		((EntityLivingBase) result.entityHit).addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 200));
                    		((EntityLivingBase) result.entityHit).addPotionEffect(new PotionEffect(MobEffects.REGENERATION, 200, 4));
                    		((EntityLivingBase) result.entityHit).addPotionEffect(new PotionEffect(MobEffects.SATURATION, 1, 4));
                    		((EntityLivingBase) result.entityHit).heal(this.getDamage());
                    		result.entityHit.extinguish();
                        	if (result.entityHit instanceof EntityAnimal)
                        	{
                        		if (((EntityAnimal)result.entityHit).isChild())
                            		((EntityAnimal)result.entityHit).addGrowth((int)(this.getDamage() * 100));
                        		else
                            		((EntityAnimal)result.entityHit).setInLove(null);
                        	}
                    	}
                    }
                	
                    if (attack)
                    {
                        this.copyLocationAndAnglesFrom(result.entityHit);
                        if (result.entityHit.isEntityAlive())
                        {
                            this.applyEnchantments(this.shootingEntity, result.entityHit);
                        }
                        else
                        {
                        	if (shootingEntity instanceof EntityBaseWither)
                        		((EntityBaseWither)shootingEntity).heal(5D);
                        	else
                        		shootingEntity.heal(5F);
                            this.shootingEntity.onKillEntity((EntityLivingBase) result.entityHit);
                        }

                        this.inflictEffects((EntityLivingBase)result.entityHit);
                        this.causeExplosion();
                    }
                }
            }
        }
    }
    
	private DamageSource getDamageType(EntityLivingBase attacker, Entity target)
    {
		DamageSource source = DamageSource.causeMobDamage(attacker);
		
		if (attacker instanceof EntityPlayer)
			source = DamageSource.causePlayerDamage((EntityPlayer) attacker);
		
		switch (this.getType())
		{
		case 14:
			target.setLocationAndAngles(target.posX + (this.rand.nextDouble() - 0.5D) * 64.0D, target.posY, target.posZ + (this.rand.nextDouble() - 0.5D) * 64.0D, 0, 0);
			target.world.playSound((EntityPlayer)null, target.prevPosX, target.prevPosY, target.prevPosZ, SoundEvents.ENTITY_ENDERMEN_TELEPORT, target.getSoundCategory(), 1.0F, 1.0F);
			target.playSound(SoundEvents.ENTITY_ENDERMEN_TELEPORT, 1.0F, 1.0F);
			break;
		}
		
		return source;
    }
    
    private void causeExplosion()
    {
    	boolean flag = net.minecraftforge.event.ForgeEventFactory.getMobGriefingEvent(this.world, this.shootingEntity);

        int i1 = MathHelper.floor(this.posX);
        int i = MathHelper.floor(this.posY + 0.5D);
        int j1 = MathHelper.floor(this.posZ);
        BlockPos pos = new BlockPos(i1, i, j1);
        IBlockState state = this.world.getBlockState(pos);
        int blockrad = (int)(this.getRadius() * 0.5F);
        
        if (MoWithers.isAnUnbreakable(state.getBlock()))
        	pos.up();
        
    	if (this.canBurn() && state.getBlock().isReplaceable(world, pos))
    	{
            this.world.setBlockState(pos, Blocks.FIRE.getDefaultState());
    	}
        
    	if (this.getType() == 2)
    	{
    		blockrad = 1 * this.world.getDifficulty().getDifficultyId();
    	}
    	
    	if (this.getType() == 3 || this.getType() == 9 || this.getType() == 20)
    	{
    		blockrad = 1;
    	}
    	
    	if (this.getType() == 5 && flag)
    	{
            for (int l1 = (int)(-this.getRadius() * 0.5F); l1 <= (int)(this.getRadius() * 0.5F); l1++) 
            {
              for (int i2 = (int)(-this.getRadius() * 0.5F); i2 <= (int)(this.getRadius() * 0.5F); i2++) 
              {
                for (int j = (int)(-this.getRadius() * 0.5F); j <= (int)(this.getRadius() * 0.5F); j++)
                {
                  int j2 = i1 + l1;
                  int k = i + j;
                  int l = j1 + i2;
                  BlockPos blockpos = new BlockPos(j2, k, l);
                  IBlockState iblockstate = this.world.getBlockState(blockpos);
                  Block block = iblockstate.getBlock();
                  
                  if (!MoWithers.isAnUnbreakable(block) && !block.isAir(iblockstate, world, blockpos)) 
                  {
              		if (shootingEntity instanceof EntityWitherVoid)
              		EntityWitherVoid.consumeBlock((EntityWitherVoid)shootingEntity, blockpos, world);
                  }
                }
              }
            }
            
    		flag = false;
    	}
    	
    	if (this.getPlacedBlockState() != null && this.getPlacedBlockState() != Blocks.AIR.getDefaultState() && flag)
    	{
    		this.placeBlocks(blockrad, i1, i, j1, this.getPlacedBlockState());
    		flag = false;
    	}
    	
    	if (this.getType() == 10 || this.getType() == 11)
    	{
            this.world.addWeatherEffect(new EntityLightningBolt(this.world, i1, i, j1, false));
    	}
        
    	if (this.getType() == 16)
    	{	
    		MoWithers.instantGrow(world, this.getPosition(), rand);
    		MoWithers.instantGrow(world, this.getPosition().down(), rand);
    	}
    	
        if (this.getType() == 17 && shootingEntity != null && shootingEntity instanceof EntityBaseWither && !((EntityBaseWither)shootingEntity).isArmored())
        {
            EntityAreaEffectCloud entityareaeffectcloud = new EntityAreaEffectCloud(this.world, this.posX, this.posY, this.posZ);
            entityareaeffectcloud.copyLocationAndAnglesFrom(this);
            entityareaeffectcloud.setOwner(this.shootingEntity);
            entityareaeffectcloud.setParticle(EnumParticleTypes.DRAGON_BREATH);
            entityareaeffectcloud.setRadius(this.getRadius() * 0.25F);
            entityareaeffectcloud.setDuration(60);
            entityareaeffectcloud.addEffect(new PotionEffect(MobEffects.INSTANT_DAMAGE, 1, 9));
            this.world.playEvent(2006, new BlockPos(this.posX, this.posY, this.posZ), 0);
            this.world.spawnEntity(entityareaeffectcloud);
        }
    	
        if (this.getType() == 21)
        {
        	for (int k = 0; k <= Maths.random(5, 20); ++k)
        	{
                EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, posX, posY, posZ, shootingEntity);
                entitytntprimed.setFuse((short)(world.rand.nextInt(entitytntprimed.getFuse() / 4) + entitytntprimed.getFuse() / 8) + 10);
                this.world.spawnEntity(entitytntprimed);
        	}
        }
    	
        List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().grow(this.getRadius() >= 32D ? 32D : this.getRadius()));

        for (Entity entity : list)
        {
            if (shootingEntity != null && !this.world.isRemote)
            {
            	if (this.getType() != 16)
            	{
            		float damage = this.getDamage() - (float)this.getDistanceSq(entity);
            		
            		if (this.getDistanceSq(entity) <= 1D)
            			damage = this.getDamage();
            		
            		if (damage <= 0)
            			damage = 0;
            		
                    if (entity instanceof EntityPlayer && entity == shootingEntity)
                    	damage *= 0.01F;
            		
                    if (entity.isEntityAlive())
                        this.applyEnchantments(this.shootingEntity, entity);
                    if (entity instanceof EntityLivingBase && entity != shootingEntity)
                    	entity.attackEntityFrom(this.getDamageType(shootingEntity, entity), damage);
                    double d1 = this.getRadius() * 2D;
                    if (d1 <= 1D)
                    	d1 = 2D;
                    if (this.isInvulnerable())
                    	d1 *= 2D;
                    if (entity instanceof EntityPlayer && entity == shootingEntity)
                    	d1 *= 2D;
                    if (entity instanceof EntityTNTPrimed)
                    	d1 *= 0.25D;
                    double d2 = entity.posX - posX;
                    double d3 = entity.posY - posY;
                    double d4 = entity.posZ - posZ;
                    double d5 = d2 * d2 + d3 * d3 + d4 * d4;
                    if (!(entity instanceof EntityFireball) && d5 != 0D)
                    entity.addVelocity(d2 / d5 * d1, d3 / d5 * d1 + (d1 / 3), d4 / d5 * d1);
                    if (entity instanceof EntityPlayerMP && entity == shootingEntity)
                    {
                    	((EntityPlayerMP)entity).connection.sendPacket(new SPacketEntityVelocity(entity.getEntityId(), entity.motionX, entity.motionY, entity.motionZ));
                    	flag = false;
                    }
                    
                    if (shootingEntity instanceof EntityPlayer && entity instanceof EntityLivingBase && !entity.isEntityAlive())
                    	shootingEntity.heal(((EntityLivingBase)entity).getMaxHealth());
            	}
            	
                if (entity instanceof EntityLivingBase)
                	this.inflictEffects((EntityLivingBase) entity);
                
                if (this.getType() == 5)
                {
                    if (entity.isEntityAlive() && !(entity instanceof EntityItem) && !(entity instanceof EntityXPOrb))
                    {
                    	entity.attackEntityFrom(DamageSource.OUT_OF_WORLD, 4.0F);
                    }
                    else
                	{
                		world.removeEntity(entity);
                		if (shootingEntity instanceof EntityWitherVoid)
                		EntityWitherVoid.consume((EntityWitherVoid)shootingEntity, entity);
                	}
                }
            }
        }
    	
    	if (this.getRadius() <= 0)
    	{
            this.world.playSound((EntityPlayer)null, this.posX, this.posY, this.posZ, SoundEvents.ENTITY_GENERIC_EXPLODE, SoundCategory.BLOCKS, 4.0F, (1.0F + (this.world.rand.nextFloat() - this.world.rand.nextFloat()) * 0.2F) * 0.7F);
            this.world.spawnParticle(EnumParticleTypes.EXPLOSION_LARGE, this.posX, this.posY, this.posZ, 1.0D, 0.0D, 0.0D);
    	}
    	else
    		this.world.newExplosion(this, this.posX, this.posY, this.posZ, this.getRadius(), this.canBurn(), flag);
        this.setDead();
    }
    
    private void inflictEffects(EntityLivingBase target)
    {
        int i = 0;

        if (this.world.getDifficulty() == EnumDifficulty.NORMAL)
        {
            i = 10;
        }
        else if (this.world.getDifficulty() == EnumDifficulty.HARD)
        {
            i = 40;
        }

        if (i > 0)
        {
        	if (!MoWithers.isWitherMob(target) && this.getType() != 16)
        		target.addPotionEffect(new PotionEffect(MobEffects.WITHER, 20 * i, 1));
            if (this.canBurn())
            	target.setFire(i + 5);
            if (this.getType() == 5 || this.getType() == 7 || this.getType() == 11)
            	target.addPotionEffect(new PotionEffect(MobEffects.BLINDNESS, 10 * i));
            if (this.getType() == 6 || this.getType() == 11)
            	target.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20 * i, 1));
            if (this.getType() == 10 || this.getType() == 11)
            	target.addPotionEffect(new PotionEffect(MobEffects.NAUSEA, 10 * i));
            if (this.getType() == 13)
            	target.addPotionEffect(new PotionEffect(MobEffects.HUNGER, 40 * i));
        }
    }

    /**
     * Returns true if other Entities should be prevented from moving through this Entity.
     */
    public boolean canBeCollidedWith()
    {
        return this.canDeflect();
    }

    /**
     * Called when the entity is attacked.
     */
    public boolean attackEntityFrom(DamageSource source, float amount)
    {
        return this.canDeflect() ? super.attackEntityFrom(source, amount) : false;
    }

    protected void entityInit()
    {
        this.dataManager.register(INVULNERABLE, Boolean.valueOf(false));
        this.dataManager.register(BURNING, Boolean.valueOf(false));
        this.dataManager.register(DEFLECT, Boolean.valueOf(false));
        this.dataManager.register(TYPE, Integer.valueOf(0));
        this.dataManager.register(TEXTURE, "");
        this.dataManager.register(DAMAGE, Float.valueOf(5F));
        this.dataManager.register(RADIUS, Float.valueOf(1F));
        this.dataManager.register(SIZE, Float.valueOf(0.5F));
        this.dataManager.register(PLACED_BLOCK, Optional.absent());
    }
    
    /**
     * (abstract) Protected helper method to write subclass entity data to NBT.
     */
    public void writeEntityToNBT(NBTTagCompound compound)
    {
        super.writeEntityToNBT(compound);
        compound.setBoolean("Invul", this.isInvulnerable());
        compound.setBoolean("Burn", this.canBurn());
        compound.setBoolean("Deflect", this.canDeflect());
        compound.setInteger("Type", this.getType());
        compound.setFloat("Damage", this.getDamage());
        compound.setFloat("Radius", this.getRadius());
        compound.setFloat("SkullSize", this.getSkullSize());

        if (this.hasSkullTexture())
        {
            compound.setString("SkullTexture", this.getSkullTexture());
        }
        IBlockState iblockstate = this.getPlacedBlockState();

        if (iblockstate != null)
        {
            compound.setShort("carried", (short)Block.getIdFromBlock(iblockstate.getBlock()));
            compound.setShort("carriedData", (short)iblockstate.getBlock().getMetaFromState(iblockstate));
        }
    }

    /**
     * (abstract) Protected helper method to read subclass entity data from NBT.
     */
    @SuppressWarnings("deprecation")
	public void readEntityFromNBT(NBTTagCompound compound)
    {
        super.readEntityFromNBT(compound);
        this.setInvulnerable(compound.getBoolean("Invul"));
        this.setBurn(compound.getBoolean("Burn"));
        this.setDeflect(compound.getBoolean("Deflect"));
        this.setType(compound.getInteger("Type"));
        this.setDamage(compound.getFloat("Damage"));
        this.setRadius(compound.getFloat("Radius"));
        this.setSkullSize(compound.getFloat("SkullSize"));

        if (compound.hasKey("SkullTexture", 8))
        {
            this.setSkullTexture(compound.getString("SkullTexture"));
        }
        
        IBlockState iblockstate;

        if (compound.hasKey("carried", 8))
        {
            iblockstate = Block.getBlockFromName(compound.getString("carried")).getStateFromMeta(compound.getShort("carriedData") & 65535);
        }
        else
        {
            iblockstate = Block.getBlockById(compound.getShort("carried")).getStateFromMeta(compound.getShort("carriedData") & 65535);
        }

        if (iblockstate == null || iblockstate.getBlock() == null || iblockstate.getMaterial() == Material.AIR)
        {
            iblockstate = null;
        }

        this.setPlacedBlockState(iblockstate);
    }

    /**
     * Returns true if this thing is named
     */
    public boolean hasSkullTexture()
    {
        return !((String)this.dataManager.get(TEXTURE)).isEmpty();
    }

    /**
     * Sets the custom name tag for this entity
     */
    public void setSkullTexture(String name)
    {
        this.dataManager.set(TEXTURE, name);
    }

    public String getSkullTexture()
    {
        return (String)this.dataManager.get(TEXTURE);
    }

    public void setPlacedBlockState(@Nullable IBlockState state)
    {
        this.dataManager.set(PLACED_BLOCK, Optional.fromNullable(state));
    }

    @Nullable
    public IBlockState getPlacedBlockState()
    {
        return (IBlockState)((Optional<?>)this.dataManager.get(PLACED_BLOCK)).orNull();
    }

    public boolean isInvulnerable()
    {
        return ((Boolean)this.dataManager.get(INVULNERABLE)).booleanValue();
    }

    public void setInvulnerable(boolean burn)
    {
        this.dataManager.set(INVULNERABLE, Boolean.valueOf(burn));
    }
    
    public boolean canBurn()
    {
        return ((Boolean)this.dataManager.get(BURNING)).booleanValue();
    }

    public void setBurn(boolean burn)
    {
        this.dataManager.set(BURNING, Boolean.valueOf(burn));
    }
    
    public boolean canDeflect()
    {
        return ((Boolean)this.dataManager.get(DEFLECT)).booleanValue();
    }

    public void setDeflect(boolean deflect)
    {
        this.dataManager.set(DEFLECT, Boolean.valueOf(deflect));
    }

    public int getType()
    {
        return ((Integer)this.dataManager.get(TYPE)).intValue();
    }

    public void setType(int type)
    {
    	if (type == 4 || type == 7 || type == 11)
    		this.noClip = true;
        this.dataManager.set(TYPE, Integer.valueOf(type));
    }

    public float getDamage()
    {
        return ((Float)this.dataManager.get(DAMAGE)).intValue();
    }

    public void setDamage(float damage)
    {
        this.dataManager.set(DAMAGE, Float.valueOf(damage));
    }

    public float getRadius()
    {
        return ((Float)this.dataManager.get(RADIUS)).intValue();
    }

    public void setRadius(float radius)
    {
        this.dataManager.set(RADIUS, Float.valueOf(radius));
    }

    public float getSkullSize()
    {
        return ((Float)this.dataManager.get(SIZE)).intValue();
    }

    public void setSkullSize(float size)
    {
        this.dataManager.set(SIZE, Float.valueOf(size));
    }

    protected boolean isFireballFiery()
    {
        return canBurn();
    }

    public boolean isImmuneToExplosions()
    {
        return true;
    }
    
    private void placeBlocks(int rad, int x, int y, int z, IBlockState state)
    {
    	if (world.getBlockState(getPosition()).getBlock().isReplaceable(world, getPosition()))
    		this.world.setBlockState(getPosition(), state);
    	
    	--y;
    	
        for (int l1 = -rad; l1 <= rad; l1++) 
        {
            for (int i2 = -rad; i2 <= rad; i2++) 
            {
                for (int j = -rad; j <= rad; j++)
                {
                    int j2 = x + l1;
                    int k = y + j;
                    int l = z + i2;
                    BlockPos blockpos = new BlockPos(j2, k, l);
                    IBlockState iblockstate = world.getBlockState(blockpos);
                    Block block = iblockstate.getBlock();
                    
                    if (block.isReplaceable(world, blockpos) || (!MoWithers.isAnUnbreakable(block) && this.isInvulnerable())) 
                        this.world.setBlockState(blockpos, state);
                }
            }
        }
    }
    
    public void onUpdate()
    {
    	super.onUpdate();
    	
    	this.setSize(this.getSkullSize() + 0.5F, this.getSkullSize() + 0.5F);
    	
    	if (this.shootingEntity != null && (this.getDistance(shootingEntity) > 120 || this.posY > 255D || this.posY < -200D) || !this.world.isBlockLoaded(new BlockPos(this)) && this.accelerationY > -0.5D)
    		this.accelerationY -= rand.nextDouble() * 0.005D + 0.005D;
    	
    	if (!world.isRemote && world.getBlockState(new BlockPos(this.posX, this.posY, this.posZ)).isFullCube() && !world.getBlockState(new BlockPos(this.posX, this.posY, this.posZ)).isTranslucent() && this.getType() != 4)
    	{
    		this.setPosition(posX, posY + 1D, posZ);
    		this.causeExplosion();
    	}
    	
        if (!this.world.isRemote && this.world.getDifficulty() == EnumDifficulty.PEACEFUL && this.shootingEntity == null)
            this.setDead();
    	
    	if (this.isBeingRidden())
    	{
            for (Entity entity : this.getPassengers())
            {
        		if (entity instanceof EntityLivingBase)
        		{
        			((EntityLivingBase)entity).addPotionEffect(new PotionEffect(MobEffects.RESISTANCE, 20, 5, true, true));
        			entity.hurtResistantTime = 20;
        			((EntityLivingBase) entity).renderYawOffset = entity.rotationYaw = ((EntityLivingBase) entity).rotationYawHead = this.rotationYaw + 180;
        			entity.rotationPitch = this.rotationPitch;
        			((EntityLivingBase) entity).limbSwingAmount = 2;
        		}
            }
    	}
    	
    	if (this.getType() == 4 || this.getType() == 11)   
    	{
            if (this.ticksExisted % 40 == 0 && !this.isSilent())
            this.world.playSound(this.posX + 0.5D, this.posY + 0.5D, this.posZ + 0.5D, SoundEvents.ITEM_ELYTRA_FLYING, this.getSoundCategory(), 1F, 2F, false);
            
        	for (int i = 0; i < 4; ++i)
        	    this.world.spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, this.posX + (this.rand.nextGaussian() * width), this.posY + (this.rand.nextGaussian() * height), this.posZ + (this.rand.nextGaussian() * width), MathHelper.sin(this.prevRotationYaw * 3.1415927F / 180.0F), -this.motionY * 3.1415927F / 180.0F, -MathHelper.cos(this.prevRotationYaw * 3.1415927F / 180.0F), new int[0]);
        	
            List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().grow(8D * this.world.getDifficulty().getDifficultyId()));

            for (Entity entity : list)
            {
                if (entity.isEntityAlive() && !entity.getIsInvulnerable() && (entity.canBePushed() || !(entity instanceof EntityLivingBase) || (entity instanceof EntityPlayer && !((EntityPlayer)entity).capabilities.isFlying)) && !(entity instanceof EntityWitherAvatar) && !(entity instanceof EntityWitherSkullShared))
                {
                	double force = 2D;
                	if (entity instanceof EntityLivingBase && ((EntityLivingBase)entity).isSneaking())
                		force = 0.125D;
                	if (entity instanceof EntityPlayer && ((EntityPlayer)entity).capabilities.isFlying)
                		force = 0.05D;
                	entity.extinguish();
                    double d2 = this.posX - entity.posX;
                    double d3 = this.posY - entity.posY;
                    double d4 = this.posZ - entity.posZ;
                    double d5 = d2 * d2 + d3 * d3 + d4 * d4;
                    entity.addVelocity(d2 / d5 * force, d3 / d5 * force, d4 / d5 * force);
                	if (entity instanceof EntityLivingBase && this.getDistance(entity) < 2 && this.shootingEntity != null && entity != this.shootingEntity)
                	{
                    	entity.attackEntityFrom(DamageSource.IN_WALL, 0.25F);
                    	if (entity instanceof EntityCreeper)
                    	{
                    		((EntityCreeper)entity).ignite();
                    		((EntityCreeper)entity).setEntityInvulnerable(true);
                    	}
                	}
                }
            }
    	}
    	
    	if (this.getType() == 5)   
    	{
        	for (int i = 0; i < 4; ++i)
        	    this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
            List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().grow(1D));

            for (Entity entity : list)
            {
                if (entity.isEntityAlive() && !entity.getIsInvulnerable())
                {
                	entity.attackEntityFrom(DamageSource.OUT_OF_WORLD, 1.0F);
                }
            }
    	}
    	
    	if (this.getType() == 7)   
    	{
            if (this.ticksExisted % 40 == 0 && !this.isSilent())
            this.world.playSound(this.posX + 0.5D, this.posY + 0.5D, this.posZ + 0.5D, SoundEvents.ITEM_ELYTRA_FLYING, this.getSoundCategory(), 1F, 2F, false);
    		
            for (int i = 0; i < 12; ++i)
    		this.world.spawnParticle(EnumParticleTypes.BLOCK_CRACK, this.posX + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, this.getEntityBoundingBox().minY + 0.1D, this.posZ + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, 0D, 0D, 0D, Block.getStateId(Blocks.SAND.getDefaultState()));

            List<Entity> list = this.world.getEntitiesWithinAABBExcludingEntity(this, this.getEntityBoundingBox().grow(2D * this.world.getDifficulty().getDifficultyId()));

            for (Entity entity : list)
            {
                if (entity != null && (!entity.getIsInvulnerable() || (entity instanceof EntityPlayer && !((EntityPlayer)entity).capabilities.disableDamage)) && (entity.canBePushed() || !(entity instanceof EntityLivingBase)) && !(entity instanceof EntityWitherSkullShared)) 
                {
                	entity.extinguish();
                    double d2 = entity.posX - this.posX;
                    double d3 = entity.posY - this.posY;
                    double d4 = entity.posZ - this.posZ;
                    double d5 = d2 * d2 + d3 * d3 + d4 * d4;
                    entity.addVelocity(d2 / d5 * 0.125D, d3 / d5 * 0.125D, d4 / d5 * 0.125D);
                	if (entity instanceof EntityLivingBase && this.shootingEntity != null && entity != this.shootingEntity)
                	{
                    	entity.attackEntityFrom(DamageSource.FALLING_BLOCK, 0.25F);
                	}
                }
            }
    	}
    	
    	if (this.getType() == 9 || this.getType() == 11)  
    	{
        	this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
        	this.world.spawnParticle(EnumParticleTypes.LAVA, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
    	}
    	
    	if (this.getType() == 11)  
    	{
        	this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
    	}
    	
    	if (this.getType() == 17)  
    	{
        	this.world.spawnParticle(EnumParticleTypes.DRAGON_BREATH, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
        	this.world.spawnParticle(EnumParticleTypes.PORTAL, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
    	}

    	if (this.getType() == 21)  
    	{
        	this.world.spawnParticle(EnumParticleTypes.SMOKE_LARGE, this.posX + (this.rand.nextGaussian() * width * 0.5F), this.posY + (this.rand.nextDouble() * height * 0.5F), this.posZ + (this.rand.nextGaussian() * width * 0.5F), 0, 0, 0, new int[0]);
    		this.world.spawnParticle(EnumParticleTypes.BLOCK_CRACK, this.posX + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, this.getEntityBoundingBox().minY + 0.1D, this.posZ + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, 4.0D * ((double)this.rand.nextFloat() - 0.5D), 0.5D, ((double)this.rand.nextFloat() - 0.5D) * 4.0D, Block.getStateId(Blocks.TNT.getDefaultState()));
        	
            if (this.ticksExisted % 10 == 0 && !this.world.isRemote && shootingEntity != null)
            {
                EntityTNTPrimed entitytntprimed = new EntityTNTPrimed(world, posX, posY, posZ, shootingEntity);
                this.world.spawnEntity(entitytntprimed);
            }
    	}

    	if (this.getPlacedBlockState() != null)  
    	{
    		this.world.spawnParticle(EnumParticleTypes.BLOCK_CRACK, this.posX + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, this.getEntityBoundingBox().minY + 0.1D, this.posZ + ((double)this.rand.nextFloat() - 0.5D) * (double)this.width, 4.0D * ((double)this.rand.nextFloat() - 0.5D), 0.5D, ((double)this.rand.nextFloat() - 0.5D) * 4.0D, Block.getStateId(this.getPlacedBlockState()));
    	}
    }
    
    protected EnumParticleTypes getParticleType()
    {
    	switch (this.getType())
    	{
    	case 1:
            return EnumParticleTypes.SMOKE_LARGE;
    	case 2:
            return EnumParticleTypes.CRIT;
    	case 3:
            return EnumParticleTypes.WATER_SPLASH;
    	case 4:
            return EnumParticleTypes.EXPLOSION_NORMAL;
    	case 5:
            return EnumParticleTypes.SMOKE_LARGE;
    	case 6:
            return EnumParticleTypes.CRIT_MAGIC;
    	case 7:
            return EnumParticleTypes.CRIT;
    	case 8:
            return EnumParticleTypes.CLOUD;
    	case 9:
            return EnumParticleTypes.LAVA;
    	case 10:
            return EnumParticleTypes.FIREWORKS_SPARK;
    	case 12:
            return EnumParticleTypes.LAVA;
    	case 13:
            return EnumParticleTypes.SUSPENDED;
    	case 14:
            return EnumParticleTypes.PORTAL;
    	case 16:
            return EnumParticleTypes.VILLAGER_HAPPY;
    	case 17:
            return EnumParticleTypes.DRAGON_BREATH;
    	case 20:
            return EnumParticleTypes.SUSPENDED_DEPTH;
    	case 21:
            return EnumParticleTypes.SMOKE_LARGE;
    	default:
            return EnumParticleTypes.SMOKE_NORMAL;
    	}
    }

    /**
     * Return the motion factor for this projectile. The factor is multiplied by the original motion.
     */
    protected float getMotionFactor()
    {
    	switch (this.getType())
    	{
    	case 2:
            return this.isInvulnerable() ? 0.7F : 0.925F;
    	case 4:
            return 0.99F;
    	case 7:
            return 0.975F;
    	case 8:
            return 0.975F;
    	case 11:
            return 0.95F;
    	case 17:
            return 0.99F;
    	case 23:
            return this.isInvulnerable() ? 0.76F : 0.975F;
    	default:
            return this.isInvulnerable() ? 0.73F : super.getMotionFactor();
    	}
    }
}