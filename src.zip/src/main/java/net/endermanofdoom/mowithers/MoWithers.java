package net.endermanofdoom.mowithers;

import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextFormatting;
import net.minecraft.world.EnumDifficulty;
import net.minecraft.world.World;
import net.endermanofdoom.mowithers.entity.monster.*;
import net.endermanofdoom.mowithers.entity.wither.*;
import net.endermanofdoom.mowithers.events.MEvents;
import net.minecraft.advancements.Advancement;
import net.minecraft.block.Block;
import net.minecraft.block.BlockDirt;
import net.minecraft.block.IGrowable;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.*;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPostInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

import java.util.Random;

import javax.annotation.Nullable;

import org.apache.logging.log4j.Logger;

import com.google.common.base.Predicate;

@Mod(modid = MoWithers.MODID, name = MoWithers.MODNAME, version = MoWithers.VERSION)
public class MoWithers
{
	public static final String MODNAME = "Mo' Withers";
	public static final String MODID = "mowithers";
	public static final String VERSION = "0.42";
	public static final String CLIENT = "net.endermanofdoom.mowithers.ClientProxy";
	public static final String SERVER = "net.endermanofdoom.mowithers.CommonProxy";
	@SidedProxy(clientSide=CLIENT, serverSide=SERVER)
	public static CommonProxy proxy;
	@Mod.Instance
	public static MoWithers instance;
    private static Logger logger;
    @SuppressWarnings("deprecation")
	public static final EnumRarity SUPER_EPIC = EnumHelper.addRarity("SUPEREPIC", TextFormatting.DARK_PURPLE, "Super Epic");
	@SuppressWarnings("deprecation")
	public static final EnumRarity LEGENDARY = EnumHelper.addRarity("LEGENDARY", TextFormatting.GOLD, "Legendary");
    public static final CreativeTabs MO_TAB = new CreativeTabs(MODID)
    {
      public ItemStack getTabIconItem()
      {
     	 return new ItemStack(Items.NETHER_STAR);
      }
    };
    public static final Predicate<Entity> NON_WITHER_OR_NETHER_MOB = new Predicate<Entity>()
    {
        public boolean apply(@Nullable Entity p_apply_1_)
        {
            return p_apply_1_ instanceof EntityLivingBase && !MoWithers.isWitherMob((EntityLivingBase)p_apply_1_) && !MoWithers.isNetherMob((EntityLivingBase)p_apply_1_) && ((EntityLivingBase)p_apply_1_).attackable();
        }
    };
    
    @EventHandler
    public void preInit(FMLPreInitializationEvent e)
    {
        logger = e.getModLog();
		logger.info("Started The Mo' Withers Mod!");
		proxy.preInit(e);
    }

    @EventHandler
    public void init(FMLInitializationEvent e)
    {
		proxy.init(e);
    }
    
	@EventHandler
	public void postInit(FMLPostInitializationEvent e)
	{
		proxy.postInit(e);
		MinecraftForge.EVENT_BUS.register(this);
		MinecraftForge.EVENT_BUS.register(new MEvents());
		logger.info("Finished The Mo' Withers Mod!");
	}
	
	public static boolean isAdvancementActive(Entity creature, String id)
	{
		EntityPlayer player = creature.getEntityWorld().getClosestPlayerToEntity(creature, -1.0D);
		
		if (player != null)
		{
	        Advancement advancement = player.getServer().getAdvancementManager().getAdvancement(new ResourceLocation(MODID, id));

	        return advancement != null;
		}
		else
		{
			return false;
		}
	}
	
	public static boolean isWitherMob(EntityLivingBase mob)
	{
		return 	mob instanceof EntityWitherNormal || 
				mob instanceof EntityFloatingSkull ||
				mob instanceof EntityWitherSkeletonBetter || 
				mob instanceof EntityWane ||
				mob instanceof EntityBlight || 
				mob instanceof EntityAtrophy || 
				mob instanceof EntityShrivel || 
				mob instanceof EntityEndroop || 
				mob instanceof EntityEvaporation || 
				mob instanceof EntityCultist || 
				(mob instanceof EntityHostileWither && ((EntityHostileWither)mob).isViticus()) ||
				(mob instanceof EntityHostileWither && mob.isEntityUndead() && !((EntityHostileWither)mob).isSuperBoss() && !((EntityHostileWither)mob).isRaidBoss());
	}
	
	public static boolean isNetherMob(EntityLivingBase mob)
	{
		return 	mob instanceof EntityWitherNormal || 
				mob instanceof EntityWitherSkeletonBetter || 
				mob instanceof EntityBlaze ||
				mob instanceof EntityPigZombie || 
				mob instanceof EntityGhast || 
				mob instanceof EntityMagmaCube;
	}
	
    public static void instantGrow(World worldIn, BlockPos pos, Random rand)
    {
    	Block block = worldIn.getBlockState(pos).getBlock();
    	
    	if (block instanceof IGrowable)
    	{
    		((IGrowable)block).grow(worldIn, rand, pos, worldIn.getBlockState(pos));
    	}
    	
    	if (block == Blocks.DIRT && worldIn.getBlockState(pos) == block.getDefaultState().withProperty(BlockDirt.VARIANT, BlockDirt.DirtType.DIRT))
    		worldIn.setBlockState(pos, Blocks.GRASS.getDefaultState());
    }
	
    public static boolean isAnUnbreakable(Block block)
    {
    	return block == Blocks.BEDROCK || block == Blocks.BARRIER || block == Blocks.END_PORTAL_FRAME || block == Blocks.END_PORTAL || block == Blocks.PORTAL || block == Blocks.END_GATEWAY || block == Blocks.COMMAND_BLOCK || block == Blocks.CHAIN_COMMAND_BLOCK || block == Blocks.REPEATING_COMMAND_BLOCK || block == Blocks.STRUCTURE_BLOCK || block == Blocks.STRUCTURE_VOID;
    }
    
    /**
     * This method gets called when the entity kills another one.
     */
    public static void onKillEntity(EntityLivingBase killer, EntityLivingBase target)
    {
    	killer.heal(5);

        EnumDifficulty diff = killer.world.getDifficulty();
        
        if (target instanceof EntitySpider && !(target instanceof EntityWane))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntitySpider killed = (EntitySpider)target;
            EntityWane ressed = new EntityWane(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());

            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntityZombie && !(target instanceof EntityBlight))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntityZombie killed = (EntityZombie)target;
            EntityBlight ressed = new EntityBlight(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setChild(killed.isChild());
            ressed.setNoAI(killed.isAIDisabled());
            ressed.setItemStackToSlot(EntityEquipmentSlot.HEAD, killed.getItemStackFromSlot(EntityEquipmentSlot.HEAD));
            ressed.setItemStackToSlot(EntityEquipmentSlot.CHEST, killed.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
            ressed.setItemStackToSlot(EntityEquipmentSlot.LEGS, killed.getItemStackFromSlot(EntityEquipmentSlot.LEGS));
            ressed.setItemStackToSlot(EntityEquipmentSlot.FEET, killed.getItemStackFromSlot(EntityEquipmentSlot.FEET));
            ressed.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, killed.getItemStackFromSlot(EntityEquipmentSlot.MAINHAND));
            ressed.setItemStackToSlot(EntityEquipmentSlot.OFFHAND, killed.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND));
            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntityCreeper && !(target instanceof EntityAtrophy))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntityCreeper killed = (EntityCreeper)target;
            EntityAtrophy ressed = new EntityAtrophy(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());

            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntityBlaze && !(target instanceof EntityShrivel))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntityBlaze killed = (EntityBlaze)target;
            EntityShrivel ressed = new EntityShrivel(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());

            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntityEnderman && !(target instanceof EntityEndroop))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntityEnderman killed = (EntityEnderman)target;
            EntityEndroop ressed = new EntityEndroop(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());

            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntityGhast && !(target instanceof EntityEvaporation))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntityGhast killed = (EntityGhast)target;
            EntityEvaporation ressed = new EntityEvaporation(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());

            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
        
        if (target instanceof EntitySkeleton && !(target instanceof EntityWitherSkeletonBetter))
        {
            if (diff == EnumDifficulty.NORMAL && killer.getRNG().nextBoolean())
            {
                return;
            }
            
            if (diff == EnumDifficulty.EASY && killer.getRNG().nextInt(2) != 0)
            {
                return;
            }

            EntitySkeleton killed = (EntitySkeleton)target;
            EntityWitherSkeletonBetter ressed = new EntityWitherSkeletonBetter(killer.world);
            ressed.copyLocationAndAnglesFrom(killed);
            killer.world.removeEntity(killed);
            ressed.onInitialSpawn(killer.world.getDifficultyForLocation(new BlockPos(ressed)), null);
            ressed.setNoAI(killed.isAIDisabled());
            ressed.setItemStackToSlot(EntityEquipmentSlot.HEAD, killed.getItemStackFromSlot(EntityEquipmentSlot.HEAD));
            ressed.setItemStackToSlot(EntityEquipmentSlot.CHEST, killed.getItemStackFromSlot(EntityEquipmentSlot.CHEST));
            ressed.setItemStackToSlot(EntityEquipmentSlot.LEGS, killed.getItemStackFromSlot(EntityEquipmentSlot.LEGS));
            ressed.setItemStackToSlot(EntityEquipmentSlot.FEET, killed.getItemStackFromSlot(EntityEquipmentSlot.FEET));
            ressed.setItemStackToSlot(EntityEquipmentSlot.MAINHAND, killed.getItemStackFromSlot(EntityEquipmentSlot.MAINHAND));
            ressed.setItemStackToSlot(EntityEquipmentSlot.OFFHAND, killed.getItemStackFromSlot(EntityEquipmentSlot.OFFHAND));
            
            if (killed.hasCustomName())
            {
                ressed.setCustomNameTag(killed.getCustomNameTag());
                ressed.setAlwaysRenderNameTag(killed.getAlwaysRenderNameTag());
            }

            killer.world.spawnEntity(ressed);
            killer.world.playEvent((EntityPlayer)null, 1024, new BlockPos(killer), 0);
        }
    }
}
